import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Product } from '../types/product';

interface CartItem extends Product {
  quantity: number;
}

interface Withdrawal {
  id: string;
  amount: number;
  cardNumber: string;
  date: string;
  status: 'pending' | 'approved' | 'rejected';
}

interface PaymentMethod {
  id: string;
  cardNumber: string;
  expiryDate: string;
  last4: string;
  isDefault: boolean;
}

interface User {
  firstName: string;
  lastName: string;
  phone: string;
  pointsBalance: number;
  avatar?: string;
  withdrawals?: Withdrawal[];
  isAdmin?: boolean;
  products?: Product[];
  paymentMethods?: PaymentMethod[];
  orders?: any[];
  referralCount?: number;
  referralPoints?: number;
}

interface StoreState {
  user: User | null;
  cart: CartItem[];
  favorites: Product[];
  registeredUsers: Record<string, User>;
  
  // User management
  setUser: (user: User | null) => void;
  registerUser: (data: { firstName: string; lastName: string; phone: string; }) => void;
  checkUserExists: (phone: string) => boolean;
  updateUserProfile: (data: Partial<User>) => void;
  
  // Cart management
  addToCart: (product: Product) => void;
  removeFromCart: (productId: number) => void;
  updateCartQuantity: (productId: number, quantity: number) => void;
  clearCart: () => void;
  
  // Favorites management
  addToFavorites: (product: Product) => void;
  removeFromFavorites: (productId: number) => void;
  
  // Points and withdrawals
  withdrawPoints: (amount: number, cardNumber: string) => void;
  approveWithdrawal: (withdrawalId: string) => void;
  rejectWithdrawal: (withdrawalId: string) => void;
  
  // Payment methods
  addPaymentMethod: (data: { cardNumber: string; expiryDate: string; }) => void;
  removePaymentMethod: (cardId: string) => void;
  setDefaultPaymentMethod: (cardId: string) => void;
  
  // Products management
  addProduct: (product: Partial<Product>) => void;
  updateProduct: (productId: number, data: Partial<Product>) => void;
  deleteProduct: (productId: number) => void;
  approveProduct: (productId: number) => void;
  rejectProduct: (productId: number) => void;
  
  // Stats
  getStats: () => {
    totalSales: number;
    totalOrders: number;
    pendingWithdrawals: number;
    activeUsers: number;
  };
}

export const useStore = create<StoreState>()(
  persist(
    (set, get) => ({
      user: null,
      cart: [],
      favorites: [],
      registeredUsers: {
        '+7 938 996 93 32': {
          firstName: 'Админ',
          lastName: 'Системы',
          phone: '+7 938 996 93 32',
          pointsBalance: 1000,
          isAdmin: true,
          paymentMethods: [],
        },
      },

      setUser: (user) => set({ user }),

      registerUser: (data) => {
        const newUser = {
          ...data,
          pointsBalance: 0,
          withdrawals: [],
          paymentMethods: [],
        };
        set((state) => ({
          registeredUsers: {
            ...state.registeredUsers,
            [data.phone]: newUser,
          },
        }));
      },

      checkUserExists: (phone) => {
        return !!get().registeredUsers[phone];
      },

      updateUserProfile: (data) => {
        set((state) => {
          if (!state.user) return state;

          const updatedUser = {
            ...state.user,
            ...data,
          };

          return {
            user: updatedUser,
            registeredUsers: {
              ...state.registeredUsers,
              [state.user.phone]: updatedUser,
            },
          };
        });
      },

      addToCart: (product) => {
        set((state) => {
          const existingItem = state.cart.find(item => item.id === product.id);
          if (existingItem) {
            return {
              cart: state.cart.map(item =>
                item.id === product.id
                  ? { ...item, quantity: item.quantity + 1 }
                  : item
              ),
            };
          }
          return {
            cart: [...state.cart, { ...product, quantity: 1 }],
          };
        });
      },

      removeFromCart: (productId) => {
        set((state) => ({
          cart: state.cart.filter(item => item.id !== productId),
        }));
      },

      updateCartQuantity: (productId, quantity) => {
        set((state) => {
          if (quantity <= 0) {
            return {
              cart: state.cart.filter(item => item.id !== productId),
            };
          }
          return {
            cart: state.cart.map(item =>
              item.id === productId
                ? { ...item, quantity }
                : item
            ),
          };
        });
      },

      clearCart: () => set({ cart: [] }),

      addToFavorites: (product) => {
        set((state) => ({
          favorites: [...state.favorites, product],
        }));
      },

      removeFromFavorites: (productId) => {
        set((state) => ({
          favorites: state.favorites.filter(item => item.id !== productId),
        }));
      },

      withdrawPoints: (amount, cardNumber) => {
        set((state) => {
          if (!state.user) return state;

          const withdrawal = {
            id: Date.now().toString(),
            amount,
            cardNumber,
            date: new Date().toISOString(),
            status: 'pending' as const,
          };

          const updatedUser = {
            ...state.user,
            withdrawals: [...(state.user.withdrawals || []), withdrawal],
          };

          return {
            user: updatedUser,
            registeredUsers: {
              ...state.registeredUsers,
              [state.user.phone]: updatedUser,
            },
          };
        });
      },

      approveWithdrawal: (withdrawalId) => {
        set((state) => {
          if (!state.user) return state;

          const updatedWithdrawals = (state.user.withdrawals || []).map(w =>
            w.id === withdrawalId ? { ...w, status: 'approved' as const } : w
          );

          const withdrawal = updatedWithdrawals.find(w => w.id === withdrawalId);
          const updatedUser = {
            ...state.user,
            withdrawals: updatedWithdrawals,
            pointsBalance: withdrawal?.status === 'approved'
              ? state.user.pointsBalance - (withdrawal.amount || 0)
              : state.user.pointsBalance,
          };

          return {
            user: updatedUser,
            registeredUsers: {
              ...state.registeredUsers,
              [state.user.phone]: updatedUser,
            },
          };
        });
      },

      rejectWithdrawal: (withdrawalId) => {
        set((state) => {
          if (!state.user) return state;

          const updatedWithdrawals = (state.user.withdrawals || []).map(w =>
            w.id === withdrawalId ? { ...w, status: 'rejected' as const } : w
          );

          const updatedUser = {
            ...state.user,
            withdrawals: updatedWithdrawals,
          };

          return {
            user: updatedUser,
            registeredUsers: {
              ...state.registeredUsers,
              [state.user.phone]: updatedUser,
            },
          };
        });
      },

      addPaymentMethod: (data) => {
        set((state) => {
          if (!state.user) return state;

          const newCard: PaymentMethod = {
            id: Date.now().toString(),
            cardNumber: data.cardNumber,
            expiryDate: data.expiryDate,
            last4: data.cardNumber.slice(-4),
            isDefault: !(state.user?.paymentMethods || []).length,
          };

          const updatedUser = {
            ...state.user,
            paymentMethods: [...(state.user.paymentMethods || []), newCard],
          };

          return {
            user: updatedUser,
            registeredUsers: {
              ...state.registeredUsers,
              [state.user.phone]: updatedUser,
            },
          };
        });
      },

      removePaymentMethod: (cardId) => {
        set((state) => {
          if (!state.user) return state;

          const updatedMethods = (state.user.paymentMethods || []).filter(
            (method) => method.id !== cardId
          );

          const updatedUser = {
            ...state.user,
            paymentMethods: updatedMethods,
          };

          return {
            user: updatedUser,
            registeredUsers: {
              ...state.registeredUsers,
              [state.user.phone]: updatedUser,
            },
          };
        });
      },

      setDefaultPaymentMethod: (cardId) => {
        set((state) => {
          if (!state.user) return state;

          const updatedMethods = (state.user.paymentMethods || []).map((method) => ({
            ...method,
            isDefault: method.id === cardId,
          }));

          const updatedUser = {
            ...state.user,
            paymentMethods: updatedMethods,
          };

          return {
            user: updatedUser,
            registeredUsers: {
              ...state.registeredUsers,
              [state.user.phone]: updatedUser,
            },
          };
        });
      },

      addProduct: (product) => {
        set((state) => {
          if (!state.user) return state;

          const newProduct = {
            id: Date.now(),
            status: 'pending',
            ...product,
          };

          const updatedUser = {
            ...state.user,
            products: [...(state.user.products || []), newProduct],
          };

          return {
            user: updatedUser,
            registeredUsers: {
              ...state.registeredUsers,
              [state.user.phone]: updatedUser,
            },
          };
        });
      },

      updateProduct: (productId, data) => {
        set((state) => {
          if (!state.user) return state;

          const updatedProducts = (state.user.products || []).map(p =>
            p.id === productId ? { ...p, ...data } : p
          );

          const updatedUser = {
            ...state.user,
            products: updatedProducts,
          };

          return {
            user: updatedUser,
            registeredUsers: {
              ...state.registeredUsers,
              [state.user.phone]: updatedUser,
            },
          };
        });
      },

      deleteProduct: (productId) => {
        set((state) => {
          if (!state.user) return state;

          const updatedProducts = (state.user.products || []).filter(p => p.id !== productId);

          const updatedUser = {
            ...state.user,
            products: updatedProducts,
          };

          return {
            user: updatedUser,
            registeredUsers: {
              ...state.registeredUsers,
              [state.user.phone]: updatedUser,
            },
          };
        });
      },

      approveProduct: (productId) => {
        set((state) => {
          if (!state.user) return state;

          const updatedProducts = (state.user.products || []).map(p =>
            p.id === productId ? { ...p, status: 'approved' } : p
          );

          const updatedUser = {
            ...state.user,
            products: updatedProducts,
          };

          return {
            user: updatedUser,
            registeredUsers: {
              ...state.registeredUsers,
              [state.user.phone]: updatedUser,
            },
          };
        });
      },

      rejectProduct: (productId) => {
        set((state) => {
          if (!state.user) return state;

          const updatedProducts = (state.user.products || []).map(p =>
            p.id === productId ? { ...p, status: 'rejected' } : p
          );

          const updatedUser = {
            ...state.user,
            products: updatedProducts,
          };

          return {
            user: updatedUser,
            registeredUsers: {
              ...state.registeredUsers,
              [state.user.phone]: updatedUser,
            },
          };
        });
      },

      getStats: () => {
        const state = get();
        const allUsers = Object.values(state.registeredUsers);
        
        return {
          totalSales: 1000000,
          totalOrders: 150,
          pendingWithdrawals: allUsers.reduce((count, user) => 
            count + ((user.withdrawals || []).filter(w => w.status === 'pending').length), 0),
          activeUsers: allUsers.length,
        };
      },
    }),
    {
      name: 'store',
    }
  )
);