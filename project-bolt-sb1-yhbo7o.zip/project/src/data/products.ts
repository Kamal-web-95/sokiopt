import { Product } from '../types/product';

export const PALLET_TYPES = {
  24: {
    name: "Стандартный",
    dimensions: { length: 120, width: 100, height: 200 },
    maxWeight: 1800,
  },
  26: {
    name: "Средний",
    dimensions: { length: 120, width: 90, height: 200 },
    maxWeight: 1650,
  },
  32: {
    name: "Евро",
    dimensions: { length: 120, width: 80, height: 200 },
    maxWeight: 1500,
  }
};

export const products: Product[] = [
  // Мелкий опт
  {
    id: 1,
    name: "Coca-Cola (стекло)",
    volume: 0.33,
    image: "https://images.unsplash.com/photo-1622483767028-3f66f32aef97?auto=format&fit=crop&q=80&w=200",
    pricePerUnit: 45,
    pricePerPack: 1080,
    unitsPerPack: 24,
    packsPerPallet: 132,
    palletsPerTruck: 24,
    category: "retail"
  },
  {
    id: 2,
    name: "Fanta (ПЭТ)",
    volume: 1.5,
    image: "https://images.unsplash.com/photo-1624552184280-9e9631bbeee9?auto=format&fit=crop&q=80&w=200",
    pricePerUnit: 89,
    pricePerPack: 534,
    unitsPerPack: 6,
    packsPerPallet: 108,
    palletsPerTruck: 32,
    category: "retail"
  },
  {
    id: 3,
    name: "Sprite (жесть)",
    volume: 0.33,
    image: "https://images.unsplash.com/photo-1625772299848-391b6a87d7b3?auto=format&fit=crop&q=80&w=200",
    pricePerUnit: 52,
    pricePerPack: 624,
    unitsPerPack: 12,
    packsPerPallet: 200,
    palletsPerTruck: 26,
    category: "retail"
  },
  {
    id: 4,
    name: "Red Bull",
    volume: 0.25,
    image: "https://images.unsplash.com/photo-1551881192-002e02ad3d87?auto=format&fit=crop&q=80&w=200",
    pricePerUnit: 99,
    pricePerPack: 2376,
    unitsPerPack: 24,
    packsPerPallet: 108,
    palletsPerTruck: 33,
    category: "retail"
  },

  // Крупный опт
  {
    id: 5,
    name: "Coca-Cola (ПЭТ)",
    volume: 2.0,
    image: "https://images.unsplash.com/photo-1622483767028-3f66f32aef97?auto=format&fit=crop&q=80&w=200",
    pricePerUnit: 129,
    pricePerPack: 774,
    unitsPerPack: 6,
    packsPerPallet: 55,
    palletsPerTruck: 26,
    category: "wholesale"
  },
  {
    id: 6,
    name: "Fanta (стекло)",
    volume: 0.5,
    image: "https://images.unsplash.com/photo-1624552184280-9e9631bbeee9?auto=format&fit=crop&q=80&w=200",
    pricePerUnit: 59,
    pricePerPack: 1416,
    unitsPerPack: 24,
    packsPerPallet: 60,
    palletsPerTruck: 32,
    category: "wholesale"
  },
  {
    id: 7,
    name: "Mountain Dew",
    volume: 0.5,
    image: "https://images.unsplash.com/photo-1625772299848-391b6a87d7b3?auto=format&fit=crop&q=80&w=200",
    pricePerUnit: 69,
    pricePerPack: 828,
    unitsPerPack: 12,
    packsPerPallet: 108,
    palletsPerTruck: 32,
    category: "wholesale"
  },

  // Бытовая химия
  {
    id: 8,
    name: "Порошок Tide",
    volume: 3,
    image: "https://images.unsplash.com/photo-1585441695325-21557ef66366?auto=format&fit=crop&q=80&w=200",
    pricePerUnit: 349,
    pricePerPack: 2094,
    unitsPerPack: 6,
    packsPerPallet: 40,
    palletsPerTruck: 24,
    category: "chemical"
  },
  {
    id: 9,
    name: "Fairy для посуды",
    volume: 0.9,
    image: "https://images.unsplash.com/photo-1585441695325-21557ef66366?auto=format&fit=crop&q=80&w=200",
    pricePerUnit: 169,
    pricePerPack: 2028,
    unitsPerPack: 12,
    packsPerPallet: 96,
    palletsPerTruck: 32,
    category: "chemical"
  },
  {
    id: 10,
    name: "Mr. Proper",
    volume: 1.5,
    image: "https://images.unsplash.com/photo-1585441695325-21557ef66366?auto=format&fit=crop&q=80&w=200",
    pricePerUnit: 259,
    pricePerPack: 1554,
    unitsPerPack: 6,
    packsPerPallet: 108,
    palletsPerTruck: 32,
    category: "chemical"
  }
];