import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { Home } from './pages/Home';
import { Products } from './pages/Products';
import { Favorites } from './pages/Favorites';
import { Cart } from './pages/Cart';
import { Account } from './pages/Account';
import { Admin } from './pages/Admin';
import { DeliveryLocal } from './pages/DeliveryLocal';
import { DeliveryRussia } from './pages/DeliveryRussia';
import { BackButton } from './components/BackButton';

function ScrollToTop() {
  const location = useLocation();
  
  useEffect(() => {
    window.scrollTo({
      top: 0,
      behavior: 'instant'
    });
  }, [location.pathname]);
  
  return null;
}

function AppContent() {
  const location = useLocation();
  const showBackButton = location.pathname !== '/';
  const isAdminPage = location.pathname === '/admin';

  return (
    <div className="min-h-screen bg-gray-50">
      {!isAdminPage && <Header />}
      {showBackButton && !isAdminPage && <BackButton />}
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/products" element={<Products />} />
        <Route path="/favorites" element={<Favorites />} />
        <Route path="/cart" element={<Cart />} />
        <Route path="/account" element={<Account />} />
        <Route path="/admin" element={<Admin />} />
        <Route path="/delivery/local" element={<DeliveryLocal />} />
        <Route path="/delivery/russia" element={<DeliveryRussia />} />
      </Routes>
      {!isAdminPage && <Footer />}
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <ScrollToTop />
      <AppContent />
    </BrowserRouter>
  );
}