export interface Product {
  id: number;
  name: string;
  volume: number | null;
  image: string | null;
  pricePerUnit: number;
  pricePerPack: number;
  unitsPerPack: number;
  packsPerPallet: number;
  palletsPerTruck: number;
  category: string;
  description?: string;
}