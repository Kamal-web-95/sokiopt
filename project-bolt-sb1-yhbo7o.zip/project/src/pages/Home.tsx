import React from 'react';
import { Banner } from '../components/Banner';
import { DeliveryBanners } from '../components/DeliveryBanners';
import { ProductList } from '../components/ProductList';
import { Chat } from '../components/Chat';
import { CompanyInfo } from '../components/CompanyInfo';
import { OtherProducts } from '../components/OtherProducts';
import { WithdrawalHistory } from '../components/WithdrawalHistory';
import { products } from '../data/products';

const retailProducts = products.filter(p => p.category === 'retail');
const wholesaleProducts = products.filter(p => p.category === 'wholesale');
const chemicalProducts = products.filter(p => p.category === 'chemical');

export function Home() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Banner />
      <DeliveryBanners />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Price Lists */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          <ProductList title="ПРАЙС: Мелкий опт" products={retailProducts} />
          <ProductList title="ПРАЙС: Крупный опт" products={wholesaleProducts} />
          <ProductList title="ПРАЙС: Бытовая химия" products={chemicalProducts} />
        </div>

        {/* Withdrawal History Section */}
        <div className="mb-12">
          <WithdrawalHistory />
        </div>
        
        {/* Bottom Section */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
          {/* Left Column - Company Info */}
          <div className="md:col-span-4">
            <CompanyInfo />
          </div>
          
          {/* Middle Column - Chat */}
          <div className="md:col-span-4">
            <Chat />
          </div>
          
          {/* Right Column - Other Products */}
          <div className="md:col-span-4">
            <OtherProducts />
          </div>
        </div>
      </div>
    </div>
  );
}