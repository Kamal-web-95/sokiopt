import React from 'react';
import { Truck } from 'lucide-react';
import { TruckCalculator } from '../components/TruckCalculator';

export function DeliveryRussia() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="bg-white rounded-lg shadow-md p-8">
        <div className="flex items-center mb-8">
          <Truck className="h-8 w-8 text-blue-600 mr-4" />
          <h1 className="text-3xl font-bold">Доставка по России</h1>
        </div>

        <div className="space-y-8">
          <div>
            <h2 className="text-xl font-semibold mb-4">Калькулятор загрузки</h2>
            <TruckCalculator />
          </div>

          <div>
            <h2 className="text-xl font-semibold mb-4">Информация о паллетах</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-gray-50 rounded-lg">
                <h3 className="font-medium mb-2">Стандартный паллет (24 шт)</h3>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>Размеры: 100x120 см</li>
                  <li>Максимальная высота: 200 см</li>
                  <li>Максимальный вес: 1800 кг</li>
                </ul>
              </div>
              
              <div className="p-4 bg-gray-50 rounded-lg">
                <h3 className="font-medium mb-2">Средний паллет (26 шт)</h3>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>Размеры: 90x120 см</li>
                  <li>Максимальная высота: 200 см</li>
                  <li>Максимальный вес: 1650 кг</li>
                </ul>
              </div>
              
              <div className="p-4 bg-gray-50 rounded-lg">
                <h3 className="font-medium mb-2">Евро паллет (32 шт)</h3>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>Размеры: 80x120 см</li>
                  <li>Максимальная высота: 200 см</li>
                  <li>Максимальный вес: 1500 кг</li>
                </ul>
              </div>
            </div>
          </div>

          <div>
            <h2 className="text-xl font-semibold mb-4">Условия доставки</h2>
            <ul className="list-disc pl-5 space-y-2 text-gray-600">
              <li>Срок доставки: 3-7 рабочих дней</li>
              <li>Страхование груза включено в стоимость</li>
              <li>Отслеживание груза в реальном времени</li>
              <li>Возможность догрузки при наличии места</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}