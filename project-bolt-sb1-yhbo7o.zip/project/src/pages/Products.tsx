import React, { useState, useEffect } from 'react';
import { ProductList } from '../components/ProductList';
import { ViewSwitcher } from '../components/ViewSwitcher';
import { Sliders, Search, X } from 'lucide-react';
import { products } from '../data/products';

const CATEGORIES = [
  { id: 'retail', name: 'Мелкий опт' },
  { id: 'wholesale', name: 'Крупный опт' },
  { id: 'chemical', name: 'Бытовая химия' },
  { id: 'other', name: 'Товары продавцов' }
];

const BRANDS = [
  'Coca-Cola',
  'Fanta',
  'Sprite',
  'Red Bull',
  'Mountain Dew',
  'Tide',
  'Fairy',
  'Mr. Proper'
];

const VOLUMES = [0.25, 0.33, 0.5, 0.9, 1.0, 1.5, 2.0, 3.0];

export function Products() {
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [selectedBrands, setSelectedBrands] = useState<string[]>([]);
  const [selectedVolumes, setSelectedVolumes] = useState<number[]>([]);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 5000]);
  const [sortBy, setSortBy] = useState('price-asc');
  const [searchQuery, setSearchQuery] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [gridView, setGridView] = useState<'grid3' | 'grid4'>('grid4');

  // Закрываем фильтры при изменении размера экрана на десктоп
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setShowFilters(false);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const minPrice = Math.min(...products.map(p => p.pricePerUnit));
  const maxPrice = Math.max(...products.map(p => p.pricePerUnit));

  const filteredProducts = products.filter(product => {
    const matchesCategory = selectedCategories.length === 0 || selectedCategories.includes(product.category);
    const matchesBrand = selectedBrands.length === 0 || selectedBrands.includes(product.name.split(' ')[0]);
    const matchesVolume = selectedVolumes.length === 0 || selectedVolumes.includes(product.volume as number);
    const matchesPrice = product.pricePerUnit >= priceRange[0] && product.pricePerUnit <= priceRange[1];
    const matchesSearch = searchQuery === '' || 
      product.name.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesCategory && matchesBrand && matchesVolume && matchesPrice && matchesSearch;
  });

  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sortBy) {
      case 'price-asc':
        return a.pricePerUnit - b.pricePerUnit;
      case 'price-desc':
        return b.pricePerUnit - a.pricePerUnit;
      case 'name-asc':
        return a.name.localeCompare(b.name);
      case 'name-desc':
        return b.name.localeCompare(a.name);
      case 'volume-asc':
        return (a.volume as number) - (b.volume as number);
      case 'volume-desc':
        return (b.volume as number) - (a.volume as number);
      default:
        return 0;
    }
  });

  const handleCategoryChange = (categoryId: string) => {
    setSelectedCategories(prev =>
      prev.includes(categoryId)
        ? prev.filter(id => id !== categoryId)
        : [...prev, categoryId]
    );
  };

  const handleBrandChange = (brand: string) => {
    setSelectedBrands(prev =>
      prev.includes(brand)
        ? prev.filter(b => b !== brand)
        : [...prev, brand]
    );
  };

  const handleVolumeChange = (volume: number) => {
    setSelectedVolumes(prev =>
      prev.includes(volume)
        ? prev.filter(v => v !== volume)
        : [...prev, volume]
    );
  };

  const renderFilters = () => (
    <div className="space-y-6">
      {/* Поиск */}
      <div className="relative">
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Поиск товаров..."
          className="w-full pl-10 pr-4 py-2 border rounded-lg"
        />
        <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
      </div>

      {/* Категории */}
      <div className="bg-white p-4 rounded-lg shadow-sm">
        <h3 className="font-medium mb-3">Категории</h3>
        <div className="space-y-2">
          {CATEGORIES.map(category => (
            <label key={category.id} className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={selectedCategories.includes(category.id)}
                onChange={() => handleCategoryChange(category.id)}
                className="text-blue-600 rounded"
              />
              <span>{category.name}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Бренды */}
      <div className="bg-white p-4 rounded-lg shadow-sm">
        <h3 className="font-medium mb-3">Бренды</h3>
        <div className="space-y-2 max-h-48 overflow-y-auto">
          {BRANDS.map(brand => (
            <label key={brand} className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={selectedBrands.includes(brand)}
                onChange={() => handleBrandChange(brand)}
                className="text-blue-600 rounded"
              />
              <span>{brand}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Объем */}
      <div className="bg-white p-4 rounded-lg shadow-sm">
        <h3 className="font-medium mb-3">Объем</h3>
        <div className="space-y-2">
          {VOLUMES.map(volume => (
            <label key={volume} className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={selectedVolumes.includes(volume)}
                onChange={() => handleVolumeChange(volume)}
                className="text-blue-600 rounded"
              />
              <span>{volume}л</span>
            </label>
          ))}
        </div>
      </div>

      {/* Цена */}
      <div className="bg-white p-4 rounded-lg shadow-sm">
        <h3 className="font-medium mb-3">Цена</h3>
        <div className="space-y-4">
          <div className="flex items-center space-x-2">
            <input
              type="number"
              value={priceRange[0]}
              onChange={(e) => setPriceRange([parseInt(e.target.value), priceRange[1]])}
              min={minPrice}
              max={priceRange[1]}
              className="w-24 px-2 py-1 border rounded"
            />
            <span>—</span>
            <input
              type="number"
              value={priceRange[1]}
              onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value)])}
              min={priceRange[0]}
              max={maxPrice}
              className="w-24 px-2 py-1 border rounded"
            />
          </div>
          <input
            type="range"
            min={minPrice}
            max={maxPrice}
            value={priceRange[1]}
            onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value)])}
            className="w-full"
          />
        </div>
      </div>

      <button
        onClick={() => {
          setSelectedCategories([]);
          setSelectedBrands([]);
          setSelectedVolumes([]);
          setPriceRange([minPrice, maxPrice]);
          setSearchQuery('');
        }}
        className="w-full px-4 py-2 text-blue-600 border border-blue-600 rounded-lg hover:bg-blue-50"
      >
        Сбросить фильтры
      </button>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 lg:py-12">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl lg:text-3xl font-bold">Каталог товаров</h1>
        <button
          onClick={() => setShowFilters(!showFilters)}
          className="lg:hidden flex items-center space-x-2 px-4 py-2 bg-gray-100 rounded-lg"
        >
          {showFilters ? (
            <X className="h-5 w-5" />
          ) : (
            <Sliders className="h-5 w-5" />
          )}
          <span>{showFilters ? 'Закрыть' : 'Фильтры'}</span>
        </button>
      </div>

      <div className="flex flex-col lg:flex-row gap-6">
        {/* Мобильные фильтры */}
        <div
          className={`
            lg:hidden fixed inset-0 z-40 bg-white transform transition-transform duration-300 ease-in-out
            ${showFilters ? 'translate-x-0' : '-translate-x-full'}
          `}
        >
          <div className="h-full overflow-y-auto p-4">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">Фильтры</h2>
              <button
                onClick={() => setShowFilters(false)}
                className="p-2 hover:bg-gray-100 rounded-lg"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
            {renderFilters()}
          </div>
        </div>

        {/* Десктопные фильтры */}
        <div className="hidden lg:block w-64 space-y-6">
          {renderFilters()}
        </div>

        {/* Основной контент */}
        <div className="flex-1">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="px-4 py-2 border rounded-lg"
            >
              <option value="price-asc">Цена (по возрастанию)</option>
              <option value="price-desc">Цена (по убыванию)</option>
              <option value="name-asc">Название (А-Я)</option>
              <option value="name-desc">Название (Я-А)</option>
              <option value="volume-asc">Объем (по возрастанию)</option>
              <option value="volume-desc">Объем (по убыванию)</option>
            </select>
            
            <ViewSwitcher view={gridView} onChange={setGridView} />
          </div>

          {sortedProducts.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-600">По вашему запросу ничего не найдено</p>
            </div>
          ) : (
            <ProductList
              title=""
              products={sortedProducts}
              gridView={gridView}
            />
          )}
        </div>
      </div>

      {/* Затемнение фона при открытых фильтрах на мобильных */}
      {showFilters && (
        <div
          className="lg:hidden fixed inset-0 bg-black bg-opacity-50 z-30"
          onClick={() => setShowFilters(false)}
        />
      )}
    </div>
  );
}