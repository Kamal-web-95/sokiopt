import React, { useState } from 'react';
import { User, Package, CreditCard, Users, Settings, Upload, History, Wallet, ShieldCheck } from 'lucide-react';
import { useStore } from '../store/useStore';
import { ProfileEditor } from '../components/ProfileEditor';
import { PointsWithdrawal } from '../components/PointsWithdrawal';
import { AddProduct } from '../components/AddProduct';
import { PaymentMethodsManager } from '../components/PaymentMethodsManager';
import { OrderHistory } from '../components/OrderHistory';
import { ReferralSystem } from '../components/ReferralSystem';

export function Account() {
  const { user } = useStore();
  const [activeTab, setActiveTab] = useState('profile');
  const isAdmin = user?.phone === '+7 938 996 93 32';

  if (!user) {
    window.location.href = '/';
    return null;
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'profile':
        return <ProfileEditor />;
      case 'orders':
        return <OrderHistory />;
      case 'payments':
        return <PaymentMethodsManager />;
      case 'points':
        return <PointsWithdrawal />;
      case 'referrals':
        return <ReferralSystem />;
      case 'products':
        return <AddProduct />;
      default:
        return null;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {isAdmin && (
        <div className="mb-8 bg-red-50 p-4 rounded-lg border-2 border-red-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <ShieldCheck className="h-8 w-8 text-red-600 mr-3" />
              <div>
                <h2 className="text-xl font-bold text-red-700">Панель администратора</h2>
                <p className="text-red-600">У вас есть доступ к панели администратора</p>
              </div>
            </div>
            <a
              href="/admin"
              className="px-6 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
            >
              Перейти в админ-панель
            </a>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
        <div className="bg-white rounded-lg shadow-sm p-6">
          <nav className="space-y-2">
            <button
              onClick={() => setActiveTab('profile')}
              className={`w-full flex items-center space-x-2 p-2 rounded-lg ${
                activeTab === 'profile' ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-50'
              }`}
            >
              <User className="w-5 h-5" />
              <span>Профиль</span>
            </button>

            <button
              onClick={() => setActiveTab('orders')}
              className={`w-full flex items-center space-x-2 p-2 rounded-lg ${
                activeTab === 'orders' ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-50'
              }`}
            >
              <History className="w-5 h-5" />
              <span>История заказов</span>
            </button>

            <button
              onClick={() => setActiveTab('payments')}
              className={`w-full flex items-center space-x-2 p-2 rounded-lg ${
                activeTab === 'payments' ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-50'
              }`}
            >
              <CreditCard className="w-5 h-5" />
              <span>Методы оплаты</span>
            </button>

            <button
              onClick={() => setActiveTab('points')}
              className={`w-full flex items-center space-x-2 p-2 rounded-lg ${
                activeTab === 'points' ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-50'
              }`}
            >
              <Wallet className="w-5 h-5" />
              <span>Вывод баллов</span>
            </button>

            <button
              onClick={() => setActiveTab('referrals')}
              className={`w-full flex items-center space-x-2 p-2 rounded-lg ${
                activeTab === 'referrals' ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-50'
              }`}
            >
              <Users className="w-5 h-5" />
              <span>Реферальная система</span>
            </button>

            <button
              onClick={() => setActiveTab('products')}
              className={`w-full flex items-center space-x-2 p-2 rounded-lg ${
                activeTab === 'products' ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-50'
              }`}
            >
              <Package className="w-5 h-5" />
              <span>Мои товары</span>
            </button>
          </nav>
        </div>
        
        <div className="md:col-span-3">
          <div className="bg-white rounded-lg shadow-sm p-6">
            {renderContent()}
          </div>
        </div>
      </div>
    </div>
  );
}