import React, { useState } from 'react';
import { useStore } from '../store/useStore';
import { 
  Users, 
  Package, 
  CreditCard, 
  BarChart, 
  Settings,
  Check,
  X,
  Edit,
  Eye
} from 'lucide-react';

export function Admin() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const { 
    user,
    registeredUsers,
    approveWithdrawal,
    rejectWithdrawal,
    updateUserAsAdmin,
    approveProduct,
    rejectProduct,
    updateProduct,
    getStats
  } = useStore();

  // Проверка на администратора
  if (!user?.isAdmin) {
    window.location.href = '/';
    return null;
  }

  const stats = getStats();

  const renderDashboard = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h3 className="text-lg font-medium text-gray-600">Общие продажи</h3>
        <p className="text-3xl font-bold mt-2">{stats.totalSales.toLocaleString()}₽</p>
      </div>
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h3 className="text-lg font-medium text-gray-600">Всего заказов</h3>
        <p className="text-3xl font-bold mt-2">{stats.totalOrders}</p>
      </div>
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h3 className="text-lg font-medium text-gray-600">Ожидают вывода</h3>
        <p className="text-3xl font-bold mt-2">{stats.pendingWithdrawals}</p>
      </div>
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h3 className="text-lg font-medium text-gray-600">Активных пользователей</h3>
        <p className="text-3xl font-bold mt-2">{stats.activeUsers}</p>
      </div>
    </div>
  );

  const renderUsers = () => (
    <div className="bg-white rounded-lg shadow-sm">
      <div className="p-6">
        <h2 className="text-xl font-bold mb-4">Пользователи</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left py-3">Имя</th>
                <th className="text-left py-3">Телефон</th>
                <th className="text-left py-3">Баллы</th>
                <th className="text-left py-3">Действия</th>
              </tr>
            </thead>
            <tbody>
              {Object.values(registeredUsers).map((user) => (
                <tr key={user.phone} className="border-b">
                  <td className="py-3">{user.firstName} {user.lastName}</td>
                  <td className="py-3">{user.phone}</td>
                  <td className="py-3">{user.pointsBalance}</td>
                  <td className="py-3">
                    <button
                      onClick={() => {/* Открыть модальное окно редактирования */}}
                      className="text-blue-600 hover:text-blue-700"
                    >
                      <Edit className="h-5 w-5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const renderWithdrawals = () => {
    const allWithdrawals = Object.values(registeredUsers)
      .flatMap(user => 
        (user.withdrawals || []).map(withdrawal => ({
          ...withdrawal,
          userName: `${user.firstName} ${user.lastName}`,
          userPhone: user.phone,
        }))
      )
      .filter(w => w.status === 'pending')
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    return (
      <div className="bg-white rounded-lg shadow-sm">
        <div className="p-6">
          <h2 className="text-xl font-bold mb-4">Заявки на вывод средств</h2>
          <div className="space-y-4">
            {allWithdrawals.map((withdrawal) => (
              <div key={withdrawal.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium">{withdrawal.userName}</p>
                  <p className="text-sm text-gray-600">
                    {withdrawal.amount} баллов на карту •••• {withdrawal.cardNumber.slice(-4)}
                  </p>
                  <p className="text-sm text-gray-600">
                    {new Date(withdrawal.date).toLocaleDateString()}
                  </p>
                </div>
                <div className="flex space-x-2">
                  <button
                    onClick={() => approveWithdrawal(withdrawal.id)}
                    className="p-2 text-green-600 hover:bg-green-50 rounded-full"
                  >
                    <Check className="h-5 w-5" />
                  </button>
                  <button
                    onClick={() => rejectWithdrawal(withdrawal.id)}
                    className="p-2 text-red-600 hover:bg-red-50 rounded-full"
                  >
                    <X className="h-5 w-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return renderDashboard();
      case 'users':
        return renderUsers();
      case 'withdrawals':
        return renderWithdrawals();
      default:
        return null;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold">Панель администратора</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-5 gap-8">
        <div className="bg-white rounded-lg shadow-sm p-6">
          <nav className="space-y-2">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`w-full flex items-center space-x-2 p-2 rounded-lg ${
                activeTab === 'dashboard' ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-50'
              }`}
            >
              <BarChart className="w-5 h-5" />
              <span>Статистика</span>
            </button>
            <button
              onClick={() => setActiveTab('users')}
              className={`w-full flex items-center space-x-2 p-2 rounded-lg ${
                activeTab === 'users' ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-50'
              }`}
            >
              <Users className="w-5 h-5" />
              <span>Пользователи</span>
            </button>
            <button
              onClick={() => setActiveTab('withdrawals')}
              className={`w-full flex items-center space-x-2 p-2 rounded-lg ${
                activeTab === 'withdrawals' ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-50'
              }`}
            >
              <CreditCard className="w-5 h-5" />
              <span>Выводы средств</span>
            </button>
            <button
              onClick={() => setActiveTab('products')}
              className={`w-full flex items-center space-x-2 p-2 rounded-lg ${
                activeTab === 'products' ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-50'
              }`}
            >
              <Package className="w-5 h-5" />
              <span>Товары</span>
            </button>
            <button
              onClick={() => setActiveTab('settings')}
              className={`w-full flex items-center space-x-2 p-2 rounded-lg ${
                activeTab === 'settings' ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-50'
              }`}
            >
              <Settings className="w-5 h-5" />
              <span>Настройки</span>
            </button>
          </nav>
        </div>

        <div className="md:col-span-4">
          {renderContent()}
        </div>
      </div>
    </div>
  );
}