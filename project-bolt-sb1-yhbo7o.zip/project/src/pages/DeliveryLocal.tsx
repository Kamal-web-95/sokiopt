import React from 'react';
import { TruckIcon } from 'lucide-react';

export function DeliveryLocal() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="bg-white rounded-lg shadow-md p-8">
        <div className="flex items-center mb-8">
          <TruckIcon className="h-8 w-8 text-blue-600 mr-4" />
          <h1 className="text-3xl font-bold">Доставка по Чеченской Республике</h1>
        </div>

        <div className="space-y-8">
          <div>
            <h2 className="text-xl font-semibold mb-4">Тарифы доставки</h2>
            <ul className="space-y-4">
              <li className="flex items-start">
                <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded mr-3">1</span>
                <div>
                  <p className="font-medium">Базовая стоимость</p>
                  <p className="text-gray-600">1500₽ за доставку до 100 кг</p>
                </div>
              </li>
              <li className="flex items-start">
                <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded mr-3">2</span>
                <div>
                  <p className="font-medium">Объемный вес</p>
                  <p className="text-gray-600">1000₽ за каждый м³</p>
                </div>
              </li>
              <li className="flex items-start">
                <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded mr-3">3</span>
                <div>
                  <p className="font-medium">Дополнительный вес</p>
                  <p className="text-gray-600">50₽ за каждый кг свыше 100 кг</p>
                </div>
              </li>
            </ul>
          </div>

          <div>
            <h2 className="text-xl font-semibold mb-4">Условия доставки</h2>
            <div className="prose prose-blue">
              <ul className="list-disc pl-5 space-y-2 text-gray-600">
                <li>Доставка осуществляется в течение 1-2 рабочих дней</li>
                <li>Минимальная сумма заказа для доставки - 5000₽</li>
                <li>Доставка осуществляется с 9:00 до 18:00</li>
                <li>При заказе свыше 50000₽ доставка бесплатная</li>
                <li>Возможна доставка в день заказа при оформлении до 12:00</li>
              </ul>
            </div>
          </div>

          <div>
            <h2 className="text-xl font-semibold mb-4">Зоны доставки</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 bg-gray-50 rounded-lg">
                <h3 className="font-medium mb-2">Зона 1 - Стандартная доставка</h3>
                <p className="text-gray-600">Грозный и ближайшие районы</p>
              </div>
              <div className="p-4 bg-gray-50 rounded-lg">
                <h3 className="font-medium mb-2">Зона 2 - Увеличенный тариф</h3>
                <p className="text-gray-600">Отдаленные районы республики</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}