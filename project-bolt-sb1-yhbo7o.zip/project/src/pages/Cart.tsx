import React from 'react';
import { Minus, Plus, Trash2 } from 'lucide-react';
import { useStore } from '../store/useStore';
import { CheckoutForm } from '../components/CheckoutForm';

export function Cart() {
  const { cart, updateCartQuantity, removeFromCart } = useStore();
  const subtotal = cart.reduce((sum, item) => sum + item.pricePerUnit * item.quantity, 0);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-3xl font-bold mb-8">Корзина</h1>
      {cart.length === 0 ? (
        <p className="text-gray-600">Корзина пуста</p>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-4">
            {cart.map((item) => (
              <div
                key={item.id}
                className="flex items-center space-x-4 p-4 bg-white rounded-lg shadow-sm"
              >
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-16 h-16 object-cover rounded-md"
                />
                <div className="flex-grow">
                  <h3 className="font-medium">{item.name}</h3>
                  <p className="text-sm text-gray-600">Объем: {item.volume}</p>
                  <div className="mt-1 space-y-1">
                    <p className="text-sm text-gray-600">Цена за штуку: {item.pricePerUnit}₽</p>
                    <p className="text-sm text-gray-600">В упаковке: {item.unitsPerPack} шт</p>
                    <p className="text-sm text-gray-600">Цена за упаковку: {item.pricePerPack}₽</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => updateCartQuantity(item.id, item.quantity - 1)}
                    disabled={item.quantity <= 1}
                    className="p-1 text-gray-600 hover:text-blue-600 disabled:opacity-50"
                  >
                    <Minus className="h-4 w-4" />
                  </button>
                  <span className="w-8 text-center">{item.quantity}</span>
                  <button
                    onClick={() => updateCartQuantity(item.id, item.quantity + 1)}
                    className="p-1 text-gray-600 hover:text-blue-600"
                  >
                    <Plus className="h-4 w-4" />
                  </button>
                </div>
                <div className="text-right">
                  <p className="font-bold">{item.pricePerUnit * item.quantity}₽</p>
                  <button
                    onClick={() => removeFromCart(item.id)}
                    className="text-red-600 hover:text-red-700"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))}

            <div className="bg-white p-4 rounded-lg shadow-sm">
              <div className="flex justify-between text-lg font-bold">
                <span>Подытог:</span>
                <span>{subtotal}₽</span>
              </div>
            </div>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <h2 className="text-xl font-bold mb-6">Оформление заказа</h2>
            <CheckoutForm />
          </div>
        </div>
      )}
    </div>
  );
}