import React, { useState, useRef } from 'react';
import { Camera, Phone, CreditCard } from 'lucide-react';
import { useStore } from '../store/useStore';

export function ProfileEditor() {
  const { user, updateUserProfile } = useStore();
  const [firstName, setFirstName] = useState(user?.firstName || '');
  const [lastName, setLastName] = useState(user?.lastName || '');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          updateUserProfile({ avatar: reader.result });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateUserProfile({ firstName, lastName });
    alert('Профиль успешно обновлен');
  };

  // Получаем уникальные номера карт из истории выводов
  const linkedCards = user?.withdrawals
    ? [...new Set(user.withdrawals.map(w => w.cardNumber))]
    : [];

  return (
    <div className="space-y-6">
      <div className="relative w-32 h-32 mx-auto">
        <img
          src={user?.avatar || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=256&h=256'}
          alt="Profile"
          className="w-full h-full rounded-full object-cover"
        />
        <button
          onClick={() => fileInputRef.current?.click()}
          className="absolute bottom-0 right-0 p-2 bg-blue-600 text-white rounded-full hover:bg-blue-700"
        >
          <Camera className="h-5 w-5" />
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleImageChange}
          className="hidden"
        />
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Имя
          </label>
          <input
            type="text"
            value={firstName}
            onChange={(e) => setFirstName(e.target.value)}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Фамилия
          </label>
          <input
            type="text"
            value={lastName}
            onChange={(e) => setLastName(e.target.value)}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Номер телефона
          </label>
          <div className="flex items-center space-x-2 px-4 py-2 bg-gray-50 rounded-lg">
            <Phone className="h-5 w-5 text-gray-500" />
            <span>{user?.phone}</span>
          </div>
        </div>

        <button
          type="submit"
          className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700"
        >
          Сохранить изменения
        </button>
      </form>

      {linkedCards.length > 0 && (
        <div className="border-t pt-6">
          <h3 className="text-lg font-medium mb-4">Привязанные карты</h3>
          <div className="space-y-3">
            {linkedCards.map((cardNumber, index) => (
              <div
                key={index}
                className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg"
              >
                <CreditCard className="h-5 w-5 text-blue-600" />
                <span>•••• {cardNumber.slice(-4)}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}