import React from 'react';
import { Link } from './Link';
import { Truck, TruckIcon } from 'lucide-react';

export function DeliveryBanners() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Link href="/delivery/local" className="group">
          <div className="relative h-48 rounded-lg overflow-hidden">
            <img
              src="https://img.freepik.com/free-photo/city-trucks-rush-by-delivering-urgent-cargo-generated-by-ai_188544-29950.jpg?w=1380"
              alt="Доставка по ЧР"
              className="w-full h-full object-cover transition-transform group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
              <div className="text-center">
                <h3 className="text-2xl font-bold text-white mb-2">Доставка по Чеченской Республике</h3>
                <div className="inline-flex items-center text-white">
                  <TruckIcon className="h-5 w-5 mr-2" />
                  <span>Рассчитать стоимость</span>
                </div>
              </div>
            </div>
          </div>
        </Link>

        <Link href="/delivery/russia" className="group">
          <div className="relative h-48 rounded-lg overflow-hidden">
            <img
              src="https://img.freepik.com/free-photo/group-trucks-parked-row_342744-533.jpg?w=1380"
              alt="Доставка по России"
              className="w-full h-full object-cover transition-transform group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
              <div className="text-center">
                <h3 className="text-2xl font-bold text-white mb-2">Доставка по всей России</h3>
                <div className="inline-flex items-center text-white">
                  <Truck className="h-5 w-5 mr-2" />
                  <span>Рассчитать стоимость</span>
                </div>
              </div>
            </div>
          </div>
        </Link>
      </div>
    </div>
  );
}