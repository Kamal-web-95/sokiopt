import React from 'react';

export function Banner() {
  return (
    <div className="relative bg-gray-900 h-[300px] flex items-center justify-center">
      <div 
        className="absolute inset-0 bg-center bg-cover"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1581955957646-b5a446b6100a?auto=format&fit=crop&q=80&w=2000")',
          opacity: '0.4'
        }}
      />
      <div className="relative text-center">
        <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
          Оптовая доставка напитков со склада
        </h1>
        <p className="text-xl text-gray-200">
          Качественные напитки для вашего бизнеса
        </p>
      </div>
    </div>
  );
}