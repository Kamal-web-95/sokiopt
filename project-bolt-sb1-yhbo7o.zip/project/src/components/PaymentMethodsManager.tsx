import React, { useState } from 'react';
import { CreditCard, Trash2, Check } from 'lucide-react';
import { useStore } from '../store/useStore';
import InputMask from 'react-input-mask';

export function PaymentMethodsManager() {
  const { user, addPaymentMethod, removePaymentMethod, setDefaultPaymentMethod } = useStore();
  const [showAddCard, setShowAddCard] = useState(false);
  const [cardNumber, setCardNumber] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvv, setCvv] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Validate card number
    const cleanCardNumber = cardNumber.replace(/\D/g, '');
    if (cleanCardNumber.length !== 16) {
      alert('Пожалуйста, введите корректный номер карты');
      return;
    }

    // Validate expiry date
    const [month, year] = expiryDate.split('/');
    const currentYear = new Date().getFullYear() % 100;
    const currentMonth = new Date().getMonth() + 1;
    
    if (!month || !year || 
        parseInt(month) < 1 || parseInt(month) > 12 ||
        parseInt(year) < currentYear || 
        (parseInt(year) === currentYear && parseInt(month) < currentMonth)) {
      alert('Пожалуйста, введите корректный срок действия карты');
      return;
    }

    // Validate CVV
    if (cvv.length !== 3) {
      alert('Пожалуйста, введите корректный CVV код');
      return;
    }

    addPaymentMethod({
      cardNumber: cleanCardNumber,
      expiryDate,
    });

    setCardNumber('');
    setExpiryDate('');
    setCvv('');
    setShowAddCard(false);
    alert('Карта успешно добавлена');
  };

  const handleRemoveCard = (cardId: string) => {
    if (window.confirm('Вы уверены, что хотите удалить эту карту?')) {
      removePaymentMethod(cardId);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">Способы оплаты</h3>
        <button
          onClick={() => setShowAddCard(!showAddCard)}
          className="text-blue-600 hover:text-blue-700"
        >
          {showAddCard ? 'Отмена' : '+ Добавить карту'}
        </button>
      </div>

      {showAddCard && (
        <form onSubmit={handleSubmit} className="space-y-4 bg-gray-50 p-4 rounded-lg">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Номер карты
            </label>
            <InputMask
              mask="9999 9999 9999 9999"
              value={cardNumber}
              onChange={(e) => setCardNumber(e.target.value)}
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
              placeholder="____ ____ ____ ____"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Срок действия
              </label>
              <InputMask
                mask="99/99"
                value={expiryDate}
                onChange={(e) => setExpiryDate(e.target.value)}
                className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                placeholder="ММ/ГГ"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                CVV
              </label>
              <InputMask
                mask="999"
                value={cvv}
                onChange={(e) => setCvv(e.target.value)}
                className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                placeholder="___"
                type="password"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700"
          >
            Добавить карту
          </button>
        </form>
      )}

      <div className="space-y-3">
        {user?.paymentMethods?.map((method) => (
          <div
            key={method.id}
            className="flex items-center justify-between p-4 border rounded-lg"
          >
            <div className="flex items-center space-x-4">
              <CreditCard className="h-6 w-6 text-gray-600" />
              <div>
                <p className="font-medium">•••• {method.last4}</p>
                <p className="text-sm text-gray-600">Действует до: {method.expiryDate}</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              {!method.isDefault && (
                <button
                  onClick={() => setDefaultPaymentMethod(method.id)}
                  className="p-2 text-gray-600 hover:text-blue-600 rounded-full hover:bg-blue-50"
                  title="Сделать основной"
                >
                  <Check className="h-5 w-5" />
                </button>
              )}
              <button
                onClick={() => handleRemoveCard(method.id)}
                className="p-2 text-gray-600 hover:text-red-600 rounded-full hover:bg-red-50"
              >
                <Trash2 className="h-5 w-5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}