import React, { useState, useRef } from 'react';
import { CreditCard } from 'lucide-react';
import { useStore } from '../store/useStore';
import { BankCardForm } from './BankCardForm';

const DELIVERY_COSTS = {
  local: {
    small: 1500,
    medium: 3000,
    large: 5000,
  },
  russia: {
    small: 3000,
    medium: 7000,
    large: 15000,
  },
};

export function CheckoutForm() {
  const { user, cart, clearCart } = useStore();
  const [firstName, setFirstName] = useState(user?.firstName || '');
  const [lastName, setLastName] = useState(user?.lastName || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [deliveryZone, setDeliveryZone] = useState<'local' | 'russia'>('local');
  const [deliveryType, setDeliveryType] = useState<'small' | 'medium' | 'large'>('small');
  const [address, setAddress] = useState('');
  const [selectedBank, setSelectedBank] = useState<'sber' | 'tinkoff' | 'alfa'>('sber');
  const [showCardForm, setShowCardForm] = useState(false);
  const [usePoints, setUsePoints] = useState(false);
  const [pointsToUse, setPointsToUse] = useState(0);
  const phoneInputRef = useRef<HTMLInputElement>(null);

  // Calculate totals
  const subtotal = cart.reduce((sum, item) => sum + item.pricePerUnit * item.quantity, 0);
  const deliveryCost = DELIVERY_COSTS[deliveryZone][deliveryType];
  const maxPointsToUse = Math.min(user?.pointsBalance || 0, subtotal + deliveryCost);
  const total = subtotal + deliveryCost - (usePoints ? pointsToUse : 0);

  const formatPhoneNumber = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length === 0) return '';
    if (numbers.length <= 1) return `+7 (${numbers}`;
    if (numbers.length <= 4) return `+7 (${numbers.slice(1, 4)}`;
    if (numbers.length <= 7) return `+7 (${numbers.slice(1, 4)}) ${numbers.slice(4, 7)}`;
    if (numbers.length <= 9) return `+7 (${numbers.slice(1, 4)}) ${numbers.slice(4, 7)}-${numbers.slice(7, 9)}`;
    return `+7 (${numbers.slice(1, 4)}) ${numbers.slice(4, 7)}-${numbers.slice(7, 9)}-${numbers.slice(9, 11)}`;
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formattedValue = formatPhoneNumber(e.target.value);
    setPhone(formattedValue);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const order = {
      id: Date.now().toString(),
      date: new Date().toISOString(),
      customer: {
        firstName,
        lastName,
        phone,
      },
      items: cart,
      delivery: {
        type: deliveryType,
        zone: deliveryZone,
        address,
        cost: deliveryCost,
      },
      subtotal,
      total,
      pointsUsed: usePoints ? pointsToUse : 0,
      paymentMethod,
      status: 'pending',
    };
    
    const { updateUserProfile } = useStore.getState();
    if (user) {
      updateUserProfile({
        orders: [...(user.orders || []), order],
        pointsBalance: user.pointsBalance - (usePoints ? pointsToUse : 0),
      });
    }
    
    clearCart();
    alert('Заказ успешно оформлен!');
    window.location.href = '/account';
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Фамилия
          </label>
          <input
            type="text"
            value={lastName}
            onChange={(e) => setLastName(e.target.value)}
            required
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Имя
          </label>
          <input
            type="text"
            value={firstName}
            onChange={(e) => setFirstName(e.target.value)}
            required
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Номер телефона
        </label>
        <input
          ref={phoneInputRef}
          type="tel"
          value={phone}
          onChange={handlePhoneChange}
          required
          placeholder="+7 (___) ___-__-__"
          className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Зона доставки
        </label>
        <select
          value={deliveryZone}
          onChange={(e) => setDeliveryZone(e.target.value as 'local' | 'russia')}
          className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
        >
          <option value="local">По Чеченской Республике</option>
          <option value="russia">По России</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Способ доставки
        </label>
        <select
          value={deliveryType}
          onChange={(e) => setDeliveryType(e.target.value as 'small' | 'medium' | 'large')}
          className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
        >
          <option value="small">Малая машина (до 10 упаковок)</option>
          <option value="medium">Грузовик (до 70 упаковок)</option>
          <option value="large">Фура (поддоны)</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Адрес доставки
        </label>
        <textarea
          value={address}
          onChange={(e) => setAddress(e.target.value)}
          required
          rows={3}
          className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
          placeholder="Укажите полный адрес доставки"
        />
      </div>

      {user && user.pointsBalance > 0 && (
        <div className="bg-blue-50 p-4 rounded-lg">
          <label className="flex items-center space-x-2">
            <input
              type="checkbox"
              checked={usePoints}
              onChange={(e) => {
                setUsePoints(e.target.checked);
                if (e.target.checked) {
                  setPointsToUse(maxPointsToUse);
                } else {
                  setPointsToUse(0);
                }
              }}
              className="text-blue-600"
            />
            <span>Использовать баллы (доступно {user.pointsBalance} баллов)</span>
          </label>
          {usePoints && (
            <div className="mt-2">
              <input
                type="number"
                value={pointsToUse}
                onChange={(e) => setPointsToUse(Math.min(parseInt(e.target.value), maxPointsToUse))}
                min={0}
                max={maxPointsToUse}
                className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
              />
              <p className="text-sm text-gray-600 mt-1">
                Максимально можно использовать {maxPointsToUse} баллов
              </p>
            </div>
          )}
        </div>
      )}

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Способ оплаты
        </label>
        <div className="space-y-2">
          {deliveryZone === 'local' && (
            <label className="flex items-center space-x-2">
              <input
                type="radio"
                value="cash"
                checked={paymentMethod === 'cash'}
                onChange={(e) => {
                  setPaymentMethod(e.target.value);
                  setShowCardForm(false);
                }}
                className="text-blue-600"
              />
              <span>Наличными при получении</span>
            </label>
          )}
          <label className="flex items-center space-x-2">
            <input
              type="radio"
              value="card"
              checked={paymentMethod === 'card'}
              onChange={(e) => {
                setPaymentMethod(e.target.value);
                setShowCardForm(true);
              }}
              className="text-blue-600"
            />
            <span>Картой</span>
          </label>
        </div>
      </div>

      {showCardForm && (
        <div>
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Выберите банк
            </label>
            <div className="grid grid-cols-3 gap-4">
              <button
                type="button"
                onClick={() => setSelectedBank('sber')}
                className={`p-4 border rounded-lg ${
                  selectedBank === 'sber' ? 'border-blue-500 bg-blue-50' : ''
                }`}
              >
                Сбербанк
              </button>
              <button
                type="button"
                onClick={() => setSelectedBank('tinkoff')}
                className={`p-4 border rounded-lg ${
                  selectedBank === 'tinkoff' ? 'border-blue-500 bg-blue-50' : ''
                }`}
              >
                Тинькофф
              </button>
              <button
                type="button"
                onClick={() => setSelectedBank('alfa')}
                className={`p-4 border rounded-lg ${
                  selectedBank === 'alfa' ? 'border-blue-500 bg-blue-50' : ''
                }`}
              >
                Альфа-банк
              </button>
            </div>
          </div>
          <BankCardForm bank={selectedBank} />
        </div>
      )}

      <div className="border-t pt-4 space-y-2">
        <div className="flex justify-between text-sm">
          <span>Товары ({cart.length}):</span>
          <span>{subtotal}₽</span>
        </div>
        <div className="flex justify-between text-sm">
          <span>Доставка:</span>
          <span>{deliveryCost}₽</span>
        </div>
        {usePoints && pointsToUse > 0 && (
          <div className="flex justify-between text-sm text-green-600">
            <span>Баллы:</span>
            <span>-{pointsToUse}₽</span>
          </div>
        )}
        <div className="flex justify-between text-lg font-bold">
          <span>Итого к оплате:</span>
          <span>{total}₽</span>
        </div>
      </div>

      <button
        type="submit"
        className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700"
      >
        Оформить заказ
      </button>
    </form>
  );
}