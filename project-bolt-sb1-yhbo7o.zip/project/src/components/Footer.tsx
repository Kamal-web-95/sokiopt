import React from 'react';
import { Link } from './Link';
import { MessageCircle, Instagram, Send } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-gray-50 border-t">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h3 className="text-lg font-semibold mb-4">Контактная информация</h3>
            <address className="not-italic">
              <p>Адрес: ул. Примерная, д. 123, г. Москва, 123456</p>
              <p>Телефон: +7 (123) 456-78-90</p>
              <p>Email: info@example.com</p>
            </address>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Свяжитесь с нами</h3>
            <div className="flex space-x-6">
              <a
                href="https://wa.me/79389969332"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-600 hover:text-green-600 transition-colors"
              >
                <MessageCircle className="h-6 w-6" />
                <span className="sr-only">WhatsApp</span>
              </a>
              <a
                href="https://instagram.com/your-handle"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-600 hover:text-pink-600 transition-colors"
              >
                <Instagram className="h-6 w-6" />
                <span className="sr-only">Instagram</span>
              </a>
              <a
                href="https://t.me/your-handle"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-600 hover:text-blue-600 transition-colors"
              >
                <Send className="h-6 w-6" />
                <span className="sr-only">Telegram</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}