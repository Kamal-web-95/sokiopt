import React from 'react';
import { CreditCard, Copy } from 'lucide-react';

interface BankCardFormProps {
  bank: 'sber' | 'tinkoff' | 'alfa';
}

const bankColors = {
  sber: '#1A9F29',
  tinkoff: '#FFDD2D',
  alfa: '#EF3124',
};

const bankNames = {
  sber: 'Сбербанк',
  tinkoff: 'Тинькофф Банк',
  alfa: 'Альфа-банк',
};

const bankCards = {
  sber: '4276 8000 1234 5678',
  tinkoff: '5536 9137 9865 4321',
  alfa: '4477 5566 8899 0123',
};

export function BankCardForm({ bank }: BankCardFormProps) {
  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    alert('Скопировано в буфер обмена');
  };

  return (
    <div className="space-y-6">
      <div className="relative h-48 rounded-xl p-6" style={{ backgroundColor: bankColors[bank] + '15' }}>
        <div className="absolute top-4 right-4">
          <CreditCard className="h-8 w-8" style={{ color: bankColors[bank] }} />
        </div>
        <div className="space-y-4">
          <div>
            <p className="text-sm text-gray-600">{bankNames[bank]}</p>
          </div>
          <div>
            <p className="text-lg font-mono">{bankCards[bank]}</p>
          </div>
          <div className="flex justify-between items-end">
            <div>
              <p className="text-xs text-gray-600 mb-1">Держатель карты</p>
              <p className="font-mono">KAMAL ILAKHANOV</p>
            </div>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
          <div>
            <p className="text-sm text-gray-600">По номеру карты</p>
            <p className="font-mono">{bankCards[bank]}</p>
          </div>
          <button
            onClick={() => handleCopy(bankCards[bank])}
            className="p-2 text-gray-600 hover:text-blue-600"
          >
            <Copy className="h-5 w-5" />
          </button>
        </div>

        <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
          <div>
            <p className="text-sm text-gray-600">По номеру телефона</p>
            <p className="font-mono">+7 938 996 93 32</p>
          </div>
          <button
            onClick={() => handleCopy('+79389969332')}
            className="p-2 text-gray-600 hover:text-blue-600"
          >
            <Copy className="h-5 w-5" />
          </button>
        </div>

        <div className="bg-blue-50 p-4 rounded-lg">
          <p className="text-sm text-blue-800">
            Для оплаты переведите указанную сумму через ваше мобильное приложение банка на указанную карту или по номеру телефона. После перевода нажмите кнопку "Оформить заказ".
          </p>
        </div>
      </div>
    </div>
  );
}