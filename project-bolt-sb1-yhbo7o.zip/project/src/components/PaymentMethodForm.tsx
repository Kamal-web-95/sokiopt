import React, { useState } from 'react';
import { useStore } from '../store/useStore';
import InputMask from 'react-input-mask';

export function PaymentMethodForm() {
  const { addPaymentMethod } = useStore();
  const [bank, setBank] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvv, setCvv] = useState('');
  const [cardHolder, setCardHolder] = useState('');
  const [phone, setPhone] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addPaymentMethod({
      bank,
      cardNumber,
      expiryDate,
      cardHolder,
      phone,
    });
    setBank('');
    setCardNumber('');
    setExpiryDate('');
    setCvv('');
    setCardHolder('');
    setPhone('');
    alert('Карта успешно добавлена');
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Банк
        </label>
        <select
          value={bank}
          onChange={(e) => setBank(e.target.value)}
          required
          className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
        >
          <option value="">Выберите банк</option>
          <option value="sberbank">Сбербанк</option>
          <option value="tinkoff">Тинькофф</option>
          <option value="vtb">ВТБ</option>
          <option value="alfabank">Альфа-Банк</option>
          <option value="gazprombank">Газпромбанк</option>
          <option value="other">Другой банк</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Номер карты
        </label>
        <InputMask
          mask="9999 9999 9999 9999"
          value={cardNumber}
          onChange={(e) => setCardNumber(e.target.value)}
          required
          className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
          placeholder="0000 0000 0000 0000"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Номер телефона
        </label>
        <InputMask
          mask="+7 (999) 999-99-99"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          required
          className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
          placeholder="+7 (___) ___-__-__"
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Срок действия
          </label>
          <InputMask
            mask="99/99"
            value={expiryDate}
            onChange={(e) => setExpiryDate(e.target.value)}
            required
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="ММ/ГГ"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            CVV
          </label>
          <InputMask
            mask="999"
            value={cvv}
            onChange={(e) => setCvv(e.target.value)}
            required
            type="password"
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="***"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Держатель карты
        </label>
        <input
          type="text"
          value={cardHolder}
          onChange={(e) => setCardHolder(e.target.value.toUpperCase())}
          required
          placeholder="IVAN IVANOV"
          className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
        />
      </div>

      <button
        type="submit"
        className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700"
      >
        Добавить карту
      </button>
    </form>
  );
}