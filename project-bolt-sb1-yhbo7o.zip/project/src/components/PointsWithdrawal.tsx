import React, { useState, useRef } from 'react';
import { useStore } from '../store/useStore';
import { CreditCard, ShoppingCart, Clock, Check, X } from 'lucide-react';

export function PointsWithdrawal() {
  const { user, withdrawPoints } = useStore();
  const [amount, setAmount] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const cardInputRef = useRef<HTMLInputElement>(null);

  const formatCardNumber = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    const groups = [];
    
    for (let i = 0; i < numbers.length && i < 16; i += 4) {
      groups.push(numbers.slice(i, i + 4));
    }
    
    return groups.join(' ');
  };

  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formattedValue = formatCardNumber(e.target.value);
    setCardNumber(formattedValue);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const pointsAmount = parseInt(amount);
    
    if (!pointsAmount || pointsAmount <= 0) {
      alert('Пожалуйста, введите корректную сумму');
      return;
    }

    if (pointsAmount > (user?.pointsBalance || 0)) {
      alert('Недостаточно баллов');
      return;
    }

    const cleanCardNumber = cardNumber.replace(/\D/g, '');
    if (cleanCardNumber.length !== 16) {
      alert('Пожалуйста, введите корректный номер карты');
      return;
    }

    withdrawPoints(pointsAmount, cardNumber);
    setAmount('');
    setCardNumber('');
    alert('Заявка на вывод средств успешно создана');
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('ru-RU', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock className="h-5 w-5 text-yellow-500" />;
      case 'approved':
        return <Check className="h-5 w-5 text-green-500" />;
      case 'rejected':
        return <X className="h-5 w-5 text-red-500" />;
      default:
        return null;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending':
        return 'На рассмотрении';
      case 'approved':
        return 'Одобрено';
      case 'rejected':
        return 'Отклонено';
      default:
        return status;
    }
  };

  const getStatusClass = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'approved':
        return 'bg-green-100 text-green-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-blue-50 p-4 rounded-lg">
        <h3 className="font-medium mb-2">Баланс баллов</h3>
        <p className="text-2xl font-bold">{user?.pointsBalance || 0} баллов</p>
        <p className="text-sm text-gray-600 mt-1">1 балл = 1 рубль</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white p-4 rounded-lg border">
          <div className="flex items-center space-x-2 mb-3">
            <ShoppingCart className="h-5 w-5 text-blue-600" />
            <h4 className="font-medium">Использовать при покупке</h4>
          </div>
          <p className="text-sm text-gray-600">
            Используйте баллы для оплаты до 100% стоимости заказа при оформлении покупки
          </p>
        </div>

        <div className="bg-white p-4 rounded-lg border">
          <div className="flex items-center space-x-2 mb-3">
            <CreditCard className="h-5 w-5 text-blue-600" />
            <h4 className="font-medium">Вывести на карту</h4>
          </div>
          <p className="text-sm text-gray-600">
            Выведите баллы на банковскую карту по курсу 1 балл = 1 рубль
          </p>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg border">
        <h3 className="text-lg font-medium mb-4">Вывод баллов</h3>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Номер карты
            </label>
            <input
              ref={cardInputRef}
              type="text"
              value={cardNumber}
              onChange={handleCardNumberChange}
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
              placeholder="____ ____ ____ ____"
              maxLength={19}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Сумма вывода (в баллах)
            </label>
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              min="100"
              max={user?.pointsBalance || 0}
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
            />
            <div className="mt-1 flex justify-between text-sm">
              <span className="text-gray-600">Минимум: 100 баллов</span>
              <span className="text-gray-600">Доступно: {user?.pointsBalance || 0} баллов</span>
            </div>
          </div>

          <button
            type="submit"
            disabled={!amount || parseInt(amount) > (user?.pointsBalance || 0) || !cardNumber}
            className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 disabled:opacity-50"
          >
            Вывести средства
          </button>

          <div className="text-sm text-gray-600 space-y-1">
            <p>• Минимальная сумма вывода: 100 баллов</p>
            <p>• Срок обработки заявки: 1-3 рабочих дня</p>
            <p>• Комиссия за вывод: 0%</p>
          </div>
        </form>
      </div>

      {user?.withdrawals && user.withdrawals.length > 0 && (
        <div className="bg-white p-6 rounded-lg border">
          <h3 className="text-lg font-medium mb-4">История выводов</h3>
          <div className="space-y-4">
            {user.withdrawals.map((withdrawal) => (
              <div key={withdrawal.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-4">
                  {getStatusIcon(withdrawal.status)}
                  <div>
                    <p className="font-medium">{withdrawal.amount} баллов</p>
                    <p className="text-sm text-gray-600">
                      Карта: •••• {withdrawal.cardNumber.slice(-4)}
                    </p>
                    <p className="text-sm text-gray-600">{formatDate(withdrawal.date)}</p>
                  </div>
                </div>
                <span className={`px-3 py-1 rounded-full text-sm ${getStatusClass(withdrawal.status)}`}>
                  {getStatusText(withdrawal.status)}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}