import React, { useState } from 'react';
import { ShoppingCart, User, Search, Heart, ShieldCheck } from 'lucide-react';
import { Link } from './Link';
import { AuthModal } from './AuthModal';
import { useStore } from '../store/useStore';
import { SearchDropdown } from './SearchDropdown';

export function Header() {
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [isLogin, setIsLogin] = useState(true);
  const [showSearch, setShowSearch] = useState(false);
  const [showAuthMenu, setShowAuthMenu] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const { cart, favorites, user } = useStore();
  const isAdmin = user?.phone === '+7 938 996 93 32';

  const cartItemsCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const favoritesCount = favorites.length;

  const handleAuthClick = (login: boolean) => {
    setIsLogin(login);
    setShowAuthModal(true);
    setShowAuthMenu(false);
  };

  const handleSearchFocus = () => {
    setShowSearch(true);
  };

  const handleSearchBlur = () => {
    setTimeout(() => setShowSearch(false), 200);
  };

  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Link href="/" className="text-2xl font-bold">ЛОГО</Link>
            <nav className="hidden md:ml-8 md:flex md:space-x-8">
              <Link href="/">Главная</Link>
              <Link href="/products">Продукты</Link>
              <Link href="/about">О нас</Link>
              <Link href="/contacts">Контакты</Link>
            </nav>
          </div>
          
          <div className="flex items-center space-x-6">
            {isAdmin && (
              <Link
                href="/admin"
                className="flex items-center space-x-2 px-4 py-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 border-2 border-red-200"
              >
                <ShieldCheck className="h-5 w-5" />
                <span>Админ-панель</span>
              </Link>
            )}

            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onFocus={handleSearchFocus}
                onBlur={handleSearchBlur}
                placeholder="Поиск..."
                className="w-48 pl-10 pr-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
              {showSearch && searchQuery && (
                <SearchDropdown query={searchQuery} />
              )}
            </div>

            <Link href="/favorites" className="relative">
              <Heart className="h-6 w-6" />
              {favoritesCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-blue-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {favoritesCount}
                </span>
              )}
            </Link>
            
            <Link href="/cart" className="relative">
              <ShoppingCart className="h-6 w-6" />
              {cartItemsCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-blue-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {cartItemsCount}
                </span>
              )}
            </Link>
            
            <div className="relative">
              <button
                onClick={() => setShowAuthMenu(!showAuthMenu)}
                className="text-gray-700 hover:text-blue-600"
              >
                <User className="h-6 w-6" />
              </button>
              
              {showAuthMenu && !user && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-2 z-50">
                  <button
                    onClick={() => handleAuthClick(true)}
                    className="block w-full text-left px-4 py-2 hover:bg-gray-50"
                  >
                    Вход
                  </button>
                  <button
                    onClick={() => handleAuthClick(false)}
                    className="block w-full text-left px-4 py-2 hover:bg-gray-50"
                  >
                    Регистрация
                  </button>
                </div>
              )}
              
              {showAuthMenu && user && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-2 z-50">
                  <Link href="/account" className="block px-4 py-2 hover:bg-gray-50">
                    Личный кабинет
                  </Link>
                  <button
                    onClick={() => {
                      useStore.getState().setUser(null);
                      setShowAuthMenu(false);
                    }}
                    className="block w-full text-left px-4 py-2 hover:bg-gray-50 text-red-600"
                  >
                    Выйти
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {showAuthModal && (
        <AuthModal
          onClose={() => setShowAuthModal(false)}
          isLogin={isLogin}
        />
      )}
    </header>
  );
}