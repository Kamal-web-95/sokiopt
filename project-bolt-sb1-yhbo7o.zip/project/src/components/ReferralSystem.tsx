import React from 'react';
import { useStore } from '../store/useStore';
import { Copy, Users } from 'lucide-react';

export function ReferralSystem() {
  const { user } = useStore();
  const referralCode = user?.phone.replace(/\D/g, '');
  const referralLink = `https://example.com/ref/${referralCode}`;

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    alert('Скопировано в буфер обмена');
  };

  return (
    <div className="space-y-6">
      <h3 className="text-xl font-bold">Реферальная программа</h3>
      
      <div className="bg-gray-50 p-4 rounded-lg">
        <p className="text-sm text-gray-600 mb-2">Ваша реферальная ссылка:</p>
        <div className="flex space-x-2">
          <input
            type="text"
            value={referralLink}
            readOnly
            className="flex-grow px-4 py-2 bg-white rounded-lg border"
          />
          <button
            onClick={() => handleCopy(referralLink)}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            <Copy className="h-5 w-5" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="p-4 bg-white rounded-lg border">
          <h4 className="font-medium mb-2">Приглашено друзей</h4>
          <p className="text-2xl font-bold">{user?.referralCount || 0}</p>
        </div>
        <div className="p-4 bg-white rounded-lg border">
          <h4 className="font-medium mb-2">Заработано баллов</h4>
          <p className="text-2xl font-bold">{user?.referralPoints || 0}</p>
        </div>
      </div>

      <div className="bg-blue-50 p-4 rounded-lg">
        <h4 className="font-medium mb-2">Как это работает?</h4>
        <ul className="space-y-2 text-sm text-blue-800">
          <li>• Поделитесь своей реферальной ссылкой с друзьями</li>
          <li>• Получайте 50 баллов за каждого нового клиента</li>
          <li>• Ваши друзья получат 100 баллов при регистрации</li>
          <li>• Баллы можно использовать для оплаты заказов или вывести на карту</li>
        </ul>
      </div>
    </div>
  );
}