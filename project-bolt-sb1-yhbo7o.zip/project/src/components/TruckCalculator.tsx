import React, { useState, useEffect } from 'react';
import { products, PALLET_TYPES, Product } from '../data/products';

interface SelectedProduct {
  product: Product;
  pallets: number;
}

export function TruckCalculator() {
  const [selectedProducts, setSelectedProducts] = useState<SelectedProduct[]>([]);
  const [currentProduct, setCurrentProduct] = useState<Product | null>(null);
  const [palletsCount, setPalletsCount] = useState(1);
  const [trucks, setTrucks] = useState(1);

  const calculateTotalPalletSpace = () => {
    return selectedProducts.reduce((total, item) => total + item.pallets, 0);
  };

  const getAvailableSpace = () => {
    if (!currentProduct) return 0;
    const totalSpace = currentProduct.palletsPerTruck * trucks;
    const usedSpace = calculateTotalPalletSpace();
    return totalSpace - usedSpace;
  };

  const handleAddProduct = () => {
    if (!currentProduct) return;

    const newProduct = {
      product: currentProduct,
      pallets: palletsCount,
    };

    setSelectedProducts([...selectedProducts, newProduct]);
    setPalletsCount(1);
  };

  const calculateTotalPrice = () => {
    return selectedProducts.reduce((total, item) => {
      const pricePerPallet = item.product.pricePerPack * item.product.packsPerPallet;
      return total + (pricePerPallet * item.pallets);
    }, 0);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <h3 className="text-lg font-semibold mb-4">Добавить товар</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Выберите товар
              </label>
              <select
                className="w-full px-3 py-2 border rounded-lg"
                onChange={(e) => setCurrentProduct(products[parseInt(e.target.value)])}
                value={products.indexOf(currentProduct!)}
              >
                <option value="">Выберите товар</option>
                {products.map((product, index) => (
                  <option key={index} value={index}>
                    {product.name} ({product.volume}л)
                  </option>
                ))}
              </select>
            </div>

            {currentProduct && (
              <>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Количество паллет
                  </label>
                  <input
                    type="number"
                    min="1"
                    max={getAvailableSpace()}
                    value={palletsCount}
                    onChange={(e) => setPalletsCount(Math.min(parseInt(e.target.value), getAvailableSpace()))}
                    className="w-full px-3 py-2 border rounded-lg"
                  />
                  <p className="text-sm text-gray-500 mt-1">
                    Доступно места: {getAvailableSpace()} паллет
                  </p>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-medium mb-2">Информация о товаре</h4>
                  <ul className="text-sm space-y-1">
                    <li>Тип паллета: {PALLET_TYPES[currentProduct.palletsPerTruck].name}</li>
                    <li>В упаковке: {currentProduct.unitsPerPack} шт</li>
                    <li>Упаковок на паллете: {currentProduct.packsPerPallet}</li>
                    <li>Паллет в машине: {currentProduct.palletsPerTruck}</li>
                  </ul>
                </div>

                <button
                  onClick={handleAddProduct}
                  disabled={!getAvailableSpace()}
                  className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 disabled:opacity-50"
                >
                  Добавить товар
                </button>
              </>
            )}
          </div>
        </div>

        <div>
          <h3 className="text-lg font-semibold mb-4">Выбранные товары</h3>
          <div className="space-y-4">
            {selectedProducts.map((item, index) => (
              <div key={index} className="bg-gray-50 p-4 rounded-lg">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-medium">{item.product.name}</h4>
                    <p className="text-sm text-gray-600">
                      Паллет: {item.pallets} | Упаковок: {item.pallets * item.product.packsPerPallet}
                    </p>
                  </div>
                  <button
                    onClick={() => {
                      const newProducts = [...selectedProducts];
                      newProducts.splice(index, 1);
                      setSelectedProducts(newProducts);
                    }}
                    className="text-red-600 hover:text-red-700"
                  >
                    Удалить
                  </button>
                </div>
              </div>
            ))}

            {selectedProducts.length > 0 && (
              <div className="bg-blue-50 p-4 rounded-lg">
                <div className="flex justify-between items-center">
                  <span className="font-medium">Итого:</span>
                  <span className="text-2xl font-bold">{calculateTotalPrice()}₽</span>
                </div>
                <div className="mt-2 text-sm text-gray-600">
                  Всего паллет: {calculateTotalPalletSpace()}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}