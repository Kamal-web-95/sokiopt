import React from 'react';
import { useStore } from '../store/useStore';

export function OrderHistory() {
  const { user } = useStore();

  return (
    <div className="space-y-6">
      <h3 className="text-xl font-bold">История заказов</h3>
      {user?.orders?.length ? (
        user.orders.map((order, index) => (
          <div key={index} className="p-4 border rounded-lg">
            <div className="flex justify-between items-start mb-4">
              <div>
                <p className="font-medium">Заказ #{order.id}</p>
                <p className="text-sm text-gray-600">{new Date(order.date).toLocaleDateString()}</p>
              </div>
              <span className={`px-3 py-1 rounded-full text-sm ${
                order.status === 'completed' ? 'bg-green-100 text-green-800' :
                order.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                'bg-gray-100 text-gray-800'
              }`}>
                {order.status === 'completed' ? 'Выполнен' :
                 order.status === 'pending' ? 'В обработке' : 'Отменён'}
              </span>
            </div>
            <div className="space-y-2">
              {order.items.map((item, i) => (
                <div key={i} className="flex justify-between text-sm">
                  <span>{item.name} x{item.quantity}</span>
                  <span>{item.pricePerUnit * item.quantity}₽</span>
                </div>
              ))}
            </div>
            <div className="mt-4 pt-4 border-t flex justify-between">
              <span className="font-medium">Итого:</span>
              <span className="font-bold">{order.total}₽</span>
            </div>
          </div>
        ))
      ) : (
        <p className="text-gray-600">У вас пока нет заказов</p>
      )}
    </div>
  );
}