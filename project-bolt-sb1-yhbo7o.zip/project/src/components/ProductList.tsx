import React, { useState } from 'react';
import { ProductCard } from './ProductCard';
import { ProductModal } from './ProductModal';
import { useStore } from '../store/useStore';
import { Product } from '../data/products';

interface ProductListProps {
  title: string;
  products: Product[];
  gridView?: 'grid3' | 'grid4';
}

export function ProductList({ title, products, gridView }: ProductListProps) {
  const [showAll, setShowAll] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const { addToCart } = useStore();

  const displayProducts = showAll ? products : products.slice(0, 10);
  const isGridView = typeof gridView !== 'undefined';

  return (
    <div className={isGridView ? '' : 'bg-white rounded-lg shadow-md p-6'}>
      {title && <h2 className="text-2xl font-bold mb-6">{title}</h2>}
      
      {isGridView ? (
        <div className={`grid gap-4 sm:gap-6 ${
          gridView === 'grid3' 
            ? 'grid-cols-2 sm:grid-cols-2 lg:grid-cols-3' 
            : 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-4'
        }`}>
          {products.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onAddToCart={() => addToCart(product)}
              onClick={() => setSelectedProduct(product)}
              gridView={gridView}
            />
          ))}
        </div>
      ) : (
        <div className="h-[600px] overflow-y-auto space-y-4 scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100">
          {displayProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onAddToCart={() => addToCart(product)}
              onClick={() => setSelectedProduct(product)}
            />
          ))}
        </div>
      )}

      {!isGridView && products.length > 10 && !showAll && (
        <button
          onClick={() => setShowAll(true)}
          className="w-full mt-6 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          Показать еще ({products.length - 10})
        </button>
      )}
      
      {selectedProduct && (
        <ProductModal
          product={selectedProduct}
          onClose={() => setSelectedProduct(null)}
        />
      )}
    </div>
  );
}