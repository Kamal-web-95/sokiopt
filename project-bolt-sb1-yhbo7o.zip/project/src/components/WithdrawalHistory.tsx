import React from 'react';
import { useStore } from '../store/useStore';
import { CreditCard, ArrowRight } from 'lucide-react';

export function WithdrawalHistory() {
  const { registeredUsers } = useStore();

  // Получаем все выводы средств от всех пользователей
  const allWithdrawals = Object.values(registeredUsers)
    .flatMap(user => 
      (user.withdrawals || []).map(withdrawal => ({
        ...withdrawal,
        userName: `${user.firstName} ${user.lastName}`,
      }))
    )
    .filter(withdrawal => withdrawal.status === 'approved')
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 5); // Показываем только последние 5 успешных выводов

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('ru-RU', {
      day: 'numeric',
      month: 'long',
    });
  };

  if (allWithdrawals.length === 0) {
    return null;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-2xl font-bold mb-6">История выводов средств</h2>
        <div className="space-y-4">
          {allWithdrawals.map((withdrawal) => (
            <div
              key={withdrawal.id}
              className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
            >
              <div className="flex items-center space-x-4">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                  <CreditCard className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <p className="font-medium">{withdrawal.userName}</p>
                  <p className="text-sm text-gray-600">
                    {formatDate(withdrawal.date)}
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <span className="font-medium text-green-600">
                  {withdrawal.amount} ₽
                </span>
                <ArrowRight className="h-4 w-4 text-green-600" />
              </div>
            </div>
          ))}
        </div>
        <div className="mt-6 text-center text-sm text-gray-600">
          <p>Присоединяйтесь к нашей программе лояльности и получайте баллы за покупки</p>
          <p>1 балл = 1 рубль</p>
        </div>
      </div>
    </div>
  );
}