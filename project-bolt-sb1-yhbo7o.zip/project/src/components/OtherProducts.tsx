import React, { useState } from 'react';
import { ProductCard } from './ProductCard';
import { ProductModal } from './ProductModal';
import { useStore } from '../store/useStore';

const otherProducts = [
  {
    id: 1,
    name: 'Случайный товар 1',
    volume: '0.5л',
    pricePerUnit: 737,
    pricePerPack: 8844,
    unitsPerPack: 12,
    packsPerPallet: 80,
    palletsPerTruck: 32,
    image: 'https://images.unsplash.com/photo-1581955957646-b5a446b6100a?auto=format&fit=crop&q=80&w=100',
    seller: 'ИП Иванов',
    category: 'other',
    description: 'Качественный товар от надежного поставщика',
  },
  {
    id: 2,
    name: 'Случайный товар 2',
    volume: '1л',
    pricePerUnit: 1200,
    pricePerPack: 14400,
    unitsPerPack: 12,
    packsPerPallet: 60,
    palletsPerTruck: 32,
    image: 'https://images.unsplash.com/photo-1581955957646-b5a446b6100a?auto=format&fit=crop&q=80&w=100',
    seller: 'ООО Напитки',
    category: 'other',
    description: 'Премиальный продукт по выгодной цене',
  },
];

export function OtherProducts() {
  const { addToCart } = useStore();
  const [selectedProduct, setSelectedProduct] = useState<null | typeof otherProducts[0]>(null);

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold mb-4">Товары от других продавцов</h2>
      <div className="space-y-4">
        {otherProducts.map((product) => (
          <ProductCard
            key={product.id}
            product={product}
            onAddToCart={() => addToCart(product)}
            onClick={() => setSelectedProduct(product)}
          />
        ))}
      </div>
      
      {selectedProduct && (
        <ProductModal
          product={selectedProduct}
          onClose={() => setSelectedProduct(null)}
        />
      )}
    </div>
  );
}