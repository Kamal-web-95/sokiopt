import React, { useState, useRef } from 'react';
import { Camera, Edit, Trash2 } from 'lucide-react';
import { useStore } from '../store/useStore';

export function AddProduct() {
  const { user, addProduct, updateProduct, deleteProduct } = useStore();
  const [editingProduct, setEditingProduct] = useState<any>(null);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [pricePerUnit, setPricePerUnit] = useState('');
  const [volume, setVolume] = useState('');
  const [category, setCategory] = useState('retail');
  const [image, setImage] = useState('');
  const [unitsPerPack, setUnitsPerPack] = useState('');
  const [packsPerPallet, setPacksPerPallet] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Получаем список товаров текущего пользователя, ожидающих модерации
  const pendingProducts = user?.products?.filter(p => p.status === 'pending') || [];

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const calculatePricePerPack = () => {
    const price = parseFloat(pricePerUnit);
    const units = parseInt(unitsPerPack);
    if (!isNaN(price) && !isNaN(units)) {
      return price * units;
    }
    return 0;
  };

  const resetForm = () => {
    setName('');
    setDescription('');
    setPricePerUnit('');
    setVolume('');
    setCategory('retail');
    setImage('');
    setUnitsPerPack('');
    setPacksPerPallet('');
    setEditingProduct(null);
  };

  const handleEdit = (product: any) => {
    setEditingProduct(product);
    setName(product.name);
    setDescription(product.description || '');
    setPricePerUnit(product.pricePerUnit.toString());
    setVolume(product.volume.toString());
    setCategory(product.category);
    setImage(product.image);
    setUnitsPerPack(product.unitsPerPack.toString());
    setPacksPerPallet(product.packsPerPallet?.toString() || '');
  };

  const handleDelete = (productId: number) => {
    if (window.confirm('Вы уверены, что хотите удалить этот товар?')) {
      deleteProduct(productId);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name || !pricePerUnit || !volume || !unitsPerPack) {
      alert('Пожалуйста, заполните все обязательные поля');
      return;
    }

    const productData = {
      name,
      description,
      pricePerUnit: parseFloat(pricePerUnit),
      pricePerPack: calculatePricePerPack(),
      volume: parseFloat(volume),
      category,
      image: image || 'https://images.unsplash.com/photo-1581955957646-b5a446b6100a?auto=format&fit=crop&q=80&w=200',
      unitsPerPack: parseInt(unitsPerPack),
      packsPerPallet: packsPerPallet ? parseInt(packsPerPallet) : undefined,
    };

    if (editingProduct) {
      updateProduct(editingProduct.id, productData);
      alert('Товар успешно обновлен');
    } else {
      addProduct(productData);
      alert('Товар успешно добавлен и отправлен на модерацию');
    }
    
    resetForm();
  };

  return (
    <div className="space-y-8">
      {pendingProducts.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-lg font-medium">Товары на модерации</h3>
          <div className="space-y-4">
            {pendingProducts.map((product) => (
              <div key={product.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-4">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-16 h-16 object-cover rounded-lg"
                  />
                  <div>
                    <h4 className="font-medium">{product.name}</h4>
                    <p className="text-sm text-gray-600">
                      {product.volume}л • {product.pricePerUnit}₽/шт
                    </p>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <button
                    onClick={() => handleEdit(product)}
                    className="p-2 text-blue-600 hover:bg-blue-50 rounded-full"
                  >
                    <Edit className="h-5 w-5" />
                  </button>
                  <button
                    onClick={() => handleDelete(product.id)}
                    className="p-2 text-red-600 hover:bg-red-50 rounded-full"
                  >
                    <Trash2 className="h-5 w-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        <h3 className="text-lg font-medium">
          {editingProduct ? 'Редактирование товара' : 'Добавление нового товара'}
        </h3>

        <div className="relative w-full h-48 bg-gray-100 rounded-lg overflow-hidden">
          {image ? (
            <img
              src={image}
              alt="Product preview"
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="flex items-center justify-center h-full">
              <Camera className="h-12 w-12 text-gray-400" />
            </div>
          )}
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="absolute bottom-4 right-4 p-2 bg-blue-600 text-white rounded-full hover:bg-blue-700"
          >
            <Camera className="h-5 w-5" />
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleImageChange}
            className="hidden"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Название товара *
          </label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Описание
          </label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={3}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Цена за единицу (₽) *
            </label>
            <input
              type="number"
              value={pricePerUnit}
              onChange={(e) => setPricePerUnit(e.target.value)}
              required
              min="0"
              step="0.01"
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Объем (л) *
            </label>
            <input
              type="number"
              value={volume}
              onChange={(e) => setVolume(e.target.value)}
              required
              min="0"
              step="0.1"
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Количество в упаковке (шт) *
            </label>
            <input
              type="number"
              value={unitsPerPack}
              onChange={(e) => setUnitsPerPack(e.target.value)}
              required
              min="1"
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Количество упаковок на поддоне
            </label>
            <input
              type="number"
              value={packsPerPallet}
              onChange={(e) => setPacksPerPallet(e.target.value)}
              min="1"
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        {unitsPerPack && pricePerUnit && (
          <div className="bg-blue-50 p-4 rounded-lg">
            <p className="text-sm text-blue-800">
              Цена за упаковку: {calculatePricePerPack()}₽
            </p>
          </div>
        )}

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Категория *
          </label>
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
          >
            <option value="retail">Мелкий опт</option>
            <option value="wholesale">Крупный опт</option>
            <option value="chemical">Бытовая химия</option>
          </select>
        </div>

        <div className="flex space-x-4">
          <button
            type="submit"
            className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700"
          >
            {editingProduct ? 'Сохранить изменения' : 'Добавить товар'}
          </button>
          {editingProduct && (
            <button
              type="button"
              onClick={resetForm}
              className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
            >
              Отмена
            </button>
          )}
        </div>
      </form>
    </div>
  );
}