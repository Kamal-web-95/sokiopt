import React, { useState, useEffect } from 'react';
import { User, Package, CreditCard, Users, Settings, Upload, History, Wallet } from 'lucide-react';
import { useStore } from '../store/useStore';
import { ProfileEditor } from '../components/ProfileEditor';
import { PointsWithdrawal } from '../components/PointsWithdrawal';
import { AddProduct } from '../components/AddProduct';

export function Account() {
  const [activeTab, setActiveTab] = useState('profile');
  const { user, approveWithdrawal } = useStore();

  // Find and approve the pending withdrawal
  useEffect(() => {
    if (user?.withdrawals) {
      const pendingWithdrawal = user.withdrawals.find(
        w => w.status === 'pending' && w.amount === 100
      );
      if (pendingWithdrawal) {
        approveWithdrawal(pendingWithdrawal.id);
      }
    }
  }, [user?.withdrawals]);

  if (!user) {
    window.location.href = '/';
    return null;
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'profile':
        return <ProfileEditor />;
      
      case 'points':
        return <PointsWithdrawal />;
      
      case 'add-product':
        return <AddProduct />;
      
      default:
        return null;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
        <div className="bg-white rounded-lg shadow-sm p-6">
          <nav className="space-y-2">
            <button
              onClick={() => setActiveTab('profile')}
              className={`w-full flex items-center space-x-2 p-2 rounded-lg ${
                activeTab === 'profile' ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-50'
              }`}
            >
              <User className="w-5 h-5" />
              <span>Профиль</span>
            </button>
            <button
              onClick={() => setActiveTab('points')}
              className={`w-full flex items-center space-x-2 p-2 rounded-lg ${
                activeTab === 'points' ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-50'
              }`}
            >
              <Wallet className="w-5 h-5" />
              <span>Вывод баллов</span>
            </button>
          </nav>
        </div>
        
        <div className="md:col-span-3">
          <div className="bg-white rounded-lg shadow-sm p-6">
            {renderContent()}
          </div>
        </div>
      </div>
    </div>
  );
}