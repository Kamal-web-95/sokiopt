import React from 'react';
import { ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export function BackButton() {
  const navigate = useNavigate();

  return (
    <button
      onClick={() => navigate(-1)}
      className="fixed top-20 left-4 z-10 p-2 bg-white rounded-full shadow-md hover:bg-gray-50"
    >
      <ArrowLeft className="h-6 w-6" />
    </button>
  );
}