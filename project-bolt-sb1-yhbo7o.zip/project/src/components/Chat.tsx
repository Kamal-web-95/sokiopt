import React, { useState, useEffect, useRef } from 'react';
import { Send } from 'lucide-react';
import { useStore } from '../store/useStore';

interface Message {
  id: string;
  text: string;
  userId: string;
  userName: string;
  timestamp: string;
}

export function Chat() {
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [onlineUsers, setOnlineUsers] = useState(42); // Имитация онлайн пользователей
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { user } = useStore();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() || !user) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      text: message,
      userId: user.phone,
      userName: `${user.firstName} ${user.lastName}`,
      timestamp: new Date().toISOString(),
    };

    setMessages(prev => [...prev, newMessage]);
    setMessage('');

    // Имитация ответа другого пользователя
    setTimeout(() => {
      const randomUser = {
        id: (Math.random() * 1000).toString(),
        userName: 'Другой пользователь',
        userId: 'random-id',
      };

      const responseMessage: Message = {
        id: Date.now().toString(),
        text: 'Спасибо за сообщение!',
        userId: randomUser.userId,
        userName: randomUser.userName,
        timestamp: new Date().toISOString(),
      };

      setMessages(prev => [...prev, responseMessage]);
    }, 2000);
  };

  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString('ru-RU', {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold mb-4">Онлайн чат</h2>
      <div className="bg-gray-50 rounded-lg p-4 h-[300px] mb-4 overflow-y-auto">
        <div className="space-y-4">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${
                msg.userId === user?.phone ? 'items-end' : 'items-start'
              }`}
            >
              <div
                className={`max-w-[80%] rounded-lg p-3 ${
                  msg.userId === user?.phone
                    ? 'bg-blue-500 text-white'
                    : 'bg-gray-200'
                }`}
              >
                <div className="font-medium text-sm mb-1">{msg.userName}</div>
                <p>{msg.text}</p>
                <div className="text-xs mt-1 opacity-75">
                  {formatTime(msg.timestamp)}
                </div>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
      </div>
      <form onSubmit={handleSubmit} className="flex space-x-2">
        <input
          type="text"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Введите сообщение..."
          className="flex-grow px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
        <button
          type="submit"
          disabled={!message.trim() || !user}
          className="p-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
        >
          <Send className="h-5 w-5" />
        </button>
      </form>
      <p className="text-sm text-gray-600 mt-2">Участников онлайн: {onlineUsers}</p>
      {!user && (
        <p className="text-sm text-red-500 mt-2">
          Войдите в аккаунт, чтобы отправлять сообщения
        </p>
      )}
    </div>
  );
}