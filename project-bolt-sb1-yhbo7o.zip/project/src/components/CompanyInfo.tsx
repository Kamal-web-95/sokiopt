import React from 'react';
import { Link } from './Link';
import { 
  Award, 
  Star, 
  Shield, 
  TrendingUp, 
  Phone, 
  Truck,
  Package
} from 'lucide-react';

export function CompanyInfo() {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold mb-6">Информация о компании</h2>
      <nav className="space-y-4">
        <Link href="/certificates" className="flex items-center space-x-3 p-2 hover:bg-gray-50 rounded-lg">
          <Award className="h-5 w-5 text-blue-600" />
          <span>Сертификаты</span>
        </Link>
        
        <Link href="/reviews" className="flex items-center space-x-3 p-2 hover:bg-gray-50 rounded-lg">
          <Star className="h-5 w-5 text-blue-600" />
          <span>Отзывы</span>
        </Link>
        
        <Link href="/guarantees" className="flex items-center space-x-3 p-2 hover:bg-gray-50 rounded-lg">
          <Shield className="h-5 w-5 text-blue-600" />
          <span>Гарантии</span>
        </Link>
        
        <Link href="/investment" className="flex items-center space-x-3 p-2 hover:bg-gray-50 rounded-lg">
          <TrendingUp className="h-5 w-5 text-blue-600" />
          <span>Инвестирование</span>
        </Link>
        
        <Link href="/contacts" className="flex items-center space-x-3 p-2 hover:bg-gray-50 rounded-lg">
          <Phone className="h-5 w-5 text-blue-600" />
          <span>Контакты</span>
        </Link>
        
        <Link href="/delivery" className="flex items-center space-x-3 p-2 hover:bg-gray-50 rounded-lg">
          <Truck className="h-5 w-5 text-blue-600" />
          <span>Доставка</span>
        </Link>
        
        <Link href="/wholesale" className="flex items-center space-x-3 p-2 hover:bg-gray-50 rounded-lg">
          <Package className="h-5 w-5 text-blue-600" />
          <span>Доставка крупный опт</span>
        </Link>
      </nav>
    </div>
  );
}