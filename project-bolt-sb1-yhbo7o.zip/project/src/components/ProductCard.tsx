import React from 'react';
import { ShoppingCart, Heart, Plus, Minus } from 'lucide-react';
import { useStore } from '../store/useStore';

interface Product {
  id: number;
  name: string;
  volume: number | string;
  pricePerUnit: number;
  image: string;
  description?: string;
}

interface ProductCardProps {
  product: Product;
  onAddToCart: () => void;
  onClick: () => void;
  gridView?: 'grid3' | 'grid4';
}

export function ProductCard({ product, onAddToCart, onClick, gridView }: ProductCardProps) {
  const { cart, updateCartQuantity, favorites, addToFavorites, removeFromFavorites } = useStore();
  const cartItem = cart.find(item => item.id === product.id);
  const isFavorite = favorites.some(item => item.id === product.id);

  const handleCartClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAddToCart();
  };

  const handleQuantityChange = (e: React.MouseEvent, newQuantity: number) => {
    e.stopPropagation();
    updateCartQuantity(product.id, newQuantity);
  };

  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isFavorite) {
      removeFromFavorites(product.id);
    } else {
      addToFavorites(product);
    }
  };

  // Компактный вид для страницы продуктов
  if (gridView) {
    return (
      <div
        onClick={onClick}
        className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow cursor-pointer h-full flex flex-col"
      >
        <div className="relative">
          <img
            src={product.image}
            alt={product.name}
            className="w-full aspect-square object-cover rounded-t-lg"
          />
          <button
            onClick={handleFavoriteClick}
            className={`absolute top-2 right-2 p-1.5 rounded-full bg-white shadow-sm ${
              isFavorite ? 'text-red-500 hover:bg-red-50' : 'text-gray-400 hover:bg-gray-50'
            }`}
          >
            <Heart className="h-4 w-4" fill={isFavorite ? 'currentColor' : 'none'} />
          </button>
        </div>
        
        <div className="p-3 flex flex-col flex-grow">
          <h3 className="font-medium text-sm mb-1 line-clamp-2">{product.name}</h3>
          <p className="text-xs text-gray-600 mb-2">Объем: {product.volume}л</p>
          <div className="flex items-center justify-between mt-auto">
            <p className="font-bold text-sm">{product.pricePerUnit}₽</p>
            {cartItem ? (
              <div className="flex items-center space-x-1">
                <button
                  onClick={(e) => handleQuantityChange(e, cartItem.quantity - 1)}
                  disabled={cartItem.quantity <= 1}
                  className="p-1 text-gray-600 hover:text-blue-600 disabled:opacity-50"
                >
                  <Minus className="h-3 w-3" />
                </button>
                <span className="w-6 text-center text-sm">{cartItem.quantity}</span>
                <button
                  onClick={(e) => handleQuantityChange(e, cartItem.quantity + 1)}
                  className="p-1 text-gray-600 hover:text-blue-600"
                >
                  <Plus className="h-3 w-3" />
                </button>
              </div>
            ) : (
              <button
                onClick={handleCartClick}
                className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-full transition-colors"
              >
                <ShoppingCart className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Оригинальный вид для главной страницы
  return (
    <div
      onClick={onClick}
      className="flex items-start space-x-4 p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow cursor-pointer bg-white"
    >
      <div className="w-24 h-24 flex-shrink-0">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover rounded-lg"
        />
      </div>
      
      <div className="flex-grow">
        <h3 className="font-medium text-lg mb-1">{product.name}</h3>
        <p className="text-sm text-gray-600 mb-2">Объем: {product.volume}л</p>
        <p className="font-bold text-lg">{product.pricePerUnit}₽</p>
      </div>

      <div className="flex flex-col items-end space-y-3">
        <button
          onClick={handleFavoriteClick}
          className={`p-2 rounded-full transition-colors ${
            isFavorite ? 'text-red-500 hover:bg-red-50' : 'text-gray-400 hover:bg-gray-50'
          }`}
        >
          <Heart className="h-5 w-5" fill={isFavorite ? 'currentColor' : 'none'} />
        </button>

        {cartItem ? (
          <div className="flex items-center space-x-2">
            <button
              onClick={(e) => handleQuantityChange(e, cartItem.quantity - 1)}
              disabled={cartItem.quantity <= 1}
              className="p-1 text-gray-600 hover:text-blue-600 disabled:opacity-50"
            >
              <Minus className="h-4 w-4" />
            </button>
            <span className="w-8 text-center font-medium">{cartItem.quantity}</span>
            <button
              onClick={(e) => handleQuantityChange(e, cartItem.quantity + 1)}
              className="p-1 text-gray-600 hover:text-blue-600"
            >
              <Plus className="h-4 w-4" />
            </button>
          </div>
        ) : (
          <button
            onClick={handleCartClick}
            className="p-2 text-blue-600 hover:bg-blue-50 rounded-full transition-colors"
          >
            <ShoppingCart className="h-5 w-5" />
          </button>
        )}
      </div>
    </div>
  );
}