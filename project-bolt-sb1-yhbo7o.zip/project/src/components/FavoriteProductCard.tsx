import React from 'react';
import { Heart, ShoppingCart } from 'lucide-react';

interface Product {
  id: number;
  name: string;
  volume: number;
  pricePerUnit: number;
  image: string;
}

interface FavoriteProductCardProps {
  product: Product;
  onAddToCart: () => void;
  onRemoveFromFavorites: () => void;
}

export function FavoriteProductCard({ product, onAddToCart, onRemoveFromFavorites }: FavoriteProductCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-sm p-4 relative">
      <button
        onClick={onRemoveFromFavorites}
        className="absolute top-2 right-2 text-red-500 hover:text-red-600"
      >
        <Heart className="h-5 w-5" fill="currentColor" />
      </button>
      
      <div className="flex space-x-4">
        <img
          src={product.image}
          alt={product.name}
          className="w-24 h-24 object-cover rounded-lg"
        />
        
        <div className="flex-grow">
          <h3 className="font-medium mb-1">{product.name}</h3>
          <p className="text-sm text-gray-600 mb-2">Объем: {product.volume}л</p>
          <p className="font-bold mb-3">{product.pricePerUnit}₽</p>
          
          <button
            onClick={onAddToCart}
            className="flex items-center justify-center w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <ShoppingCart className="h-4 w-4 mr-2" />
            В корзину
          </button>
        </div>
      </div>
    </div>
  );
}