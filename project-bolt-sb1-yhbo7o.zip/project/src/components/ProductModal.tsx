import React from 'react';
import { X, Plus, Minus, Heart, Package, Boxes } from 'lucide-react';
import { useStore } from '../store/useStore';

interface Product {
  id: number;
  name: string;
  volume: string | number;
  pricePerUnit: number;
  pricePerPack: number;
  unitsPerPack: number;
  packsPerPallet: number;
  image: string;
  description?: string;
}

interface ProductModalProps {
  product: Product;
  onClose: () => void;
}

export function ProductModal({ product, onClose }: ProductModalProps) {
  const { cart, addToCart, updateCartQuantity, favorites, addToFavorites, removeFromFavorites } = useStore();
  const cartItem = cart.find(item => item.id === product.id);
  const isFavorite = favorites.some(item => item.id === product.id);

  const handleFavoriteClick = () => {
    if (isFavorite) {
      removeFromFavorites(product.id);
    } else {
      addToFavorites(product);
    }
  };

  // Расчет цены за поддон
  const pricePerPallet = product.pricePerPack * product.packsPerPallet;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg max-w-4xl w-full mx-4">
        <div className="flex justify-end p-4">
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X className="h-6 w-6" />
          </button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 p-6">
          <div>
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-[400px] object-cover rounded-lg"
            />
          </div>
          <div>
            <div className="flex justify-between items-start mb-4">
              <h2 className="text-2xl font-bold">{product.name}</h2>
              <button
                onClick={handleFavoriteClick}
                className={`p-2 rounded-full transition-colors ${
                  isFavorite ? 'text-red-500 hover:bg-red-50' : 'text-gray-400 hover:bg-gray-50'
                }`}
              >
                <Heart className="h-6 w-6" fill={isFavorite ? 'currentColor' : 'none'} />
              </button>
            </div>
            <p className="text-gray-600 mb-4">Объем: {product.volume}л</p>
            <p className="text-gray-700 mb-6">
              {product.description || 'Описание товара временно недоступно.'}
            </p>

            {/* Цены */}
            <div className="space-y-4 mb-6">
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center">
                  <Package className="h-5 w-5 mr-2 text-gray-600" />
                  <span>Цена за штуку:</span>
                </div>
                <span className="font-bold">{product.pricePerUnit}₽</span>
              </div>

              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center">
                  <Boxes className="h-5 w-5 mr-2 text-gray-600" />
                  <span>Цена за упаковку ({product.unitsPerPack} шт):</span>
                </div>
                <span className="font-bold">{product.pricePerPack}₽</span>
              </div>

              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center">
                  <Boxes className="h-5 w-5 mr-2 text-gray-600" />
                  <span>Цена за поддон ({product.packsPerPallet} уп):</span>
                </div>
                <span className="font-bold">{pricePerPallet}₽</span>
              </div>
            </div>
            
            {cartItem ? (
              <div className="flex items-center space-x-4">
                <button
                  onClick={() => updateCartQuantity(product.id, cartItem.quantity - 1)}
                  disabled={cartItem.quantity <= 1}
                  className="p-2 text-gray-600 hover:text-blue-600 disabled:opacity-50"
                >
                  <Minus className="h-5 w-5" />
                </button>
                <span className="text-xl font-medium">{cartItem.quantity}</span>
                <button
                  onClick={() => updateCartQuantity(product.id, cartItem.quantity + 1)}
                  className="p-2 text-gray-600 hover:text-blue-600"
                >
                  <Plus className="h-5 w-5" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => addToCart(product)}
                className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors"
              >
                Добавить в корзину
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}