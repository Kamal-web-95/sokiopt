import React from 'react';

interface SearchDropdownProps {
  query: string;
}

const searchResults = [
  {
    id: 1,
    name: 'Кока-Кола',
    volume: '0.5л',
    price: 89,
  },
  {
    id: 2,
    name: 'Спрайт',
    volume: '1л',
    price: 129,
  },
  {
    id: 3,
    name: 'Фанта',
    volume: '2л',
    price: 169,
  },
];

export function SearchDropdown({ query }: SearchDropdownProps) {
  const filteredResults = searchResults.filter(item =>
    item.name.toLowerCase().includes(query.toLowerCase())
  );

  if (filteredResults.length === 0) return null;

  return (
    <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-lg shadow-lg border border-gray-200 z-50">
      {filteredResults.map(item => (
        <div
          key={item.id}
          className="p-3 hover:bg-gray-50 cursor-pointer border-b last:border-b-0"
        >
          <div className="font-medium">{item.name}</div>
          <div className="text-sm text-gray-600">
            {item.volume} • {item.price}₽
          </div>
        </div>
      ))}
    </div>
  );
}