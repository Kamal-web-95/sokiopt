import React from 'react';
import { LayoutGrid, Grid3X3 } from 'lucide-react';

interface ViewSwitcherProps {
  view: 'grid3' | 'grid4';
  onChange: (view: 'grid3' | 'grid4') => void;
}

export function ViewSwitcher({ view, onChange }: ViewSwitcherProps) {
  return (
    <div className="flex items-center space-x-2 bg-white rounded-lg border p-1">
      <button
        onClick={() => onChange('grid3')}
        className={`p-1.5 rounded ${
          view === 'grid3' ? 'bg-blue-50 text-blue-600' : 'text-gray-500 hover:text-gray-700'
        }`}
        title="3 в ряд"
      >
        <Grid3X3 className="h-5 w-5" />
      </button>
      <button
        onClick={() => onChange('grid4')}
        className={`p-1.5 rounded ${
          view === 'grid4' ? 'bg-blue-50 text-blue-600' : 'text-gray-500 hover:text-gray-700'
        }`}
        title="4 в ряд"
      >
        <LayoutGrid className="h-5 w-5" />
      </button>
    </div>
  );
}